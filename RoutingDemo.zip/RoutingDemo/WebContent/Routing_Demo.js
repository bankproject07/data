var app=angular.module("mainApp",["ngRoute"])
	.config(function($routeProvider){
	$routeProvider.
	when("/fruits",{templateUrl:"Fruits.html",controller:"fruitcntrl",
			data:{customKey1:"CustomKey1",customKey2:"CustomKey2"}
	}).
	when("/veg",{templateUrl:"Veggies.html",controller:"vegetablecntrl",
		data:{customKey3:"CustomKey3",customKey4:"CustomKey4"}	
	}).
	when("/details/:foodId",{templateUrl:"Details.html",controller:"descpcntrl"})
	
});



/******** Description Controller**********/

app.controller("descpcntrl",function($scope,$routeParams,fruitService){
	
	var id=$routeParams.foodId;
	$scope.foodItem=fruitService.getFood(id);
	console.log($scope.foodItem);
	
	
});

app.controller('navctrl',function($scope,$location){
	$scope.changeLocation=function(location){
		
		switch(location)
		{
		case 'fruits':$location.path("/fruits");break;
		
		case 'veg':$location.path("/veg");break;
		}
	}
	
});

/*********Fruit Controller***********/
app.controller("fruitcntrl",function($scope,$route,$log){
	var fruits=[
	
	{name:"Grapes", image:"./images/G1.jpg"},
	{name:"Mango",image:"./images/M1.jpg"}
	];
	$scope.fruits=fruits;
	$log.info($route.current.data.customKey1);
	
	
	
	/*$scope.fruits=fruitService.getFruit;
	console.log($scope.fruits)*/
});




/*************** vegetable Controller***************/
app.controller("vegetablecntrl",function($scope,$route,$log){
	
	var veggies=[
	{name:"beans",image:"./images/V1.jpg"},
	{name:"carrot",image:"./images/V2.jpg"},
	{name:"CauliFlower",image:"./images/V3.jpg"}
			];
		$scope.veggies=veggies;
		
		$log.info($route.current.data.customKey3);
	
	/*console.log($scope.veggies);$scope.veggies=fruitService.getVegetables;*/

});
