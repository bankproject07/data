/**
 * 
 */

app.factory("fruitService",function(){
		var list=new Array(
		          {id:1,name:"Grapes", image:"./images/G1.jpg",type:"F",desc:"Description under contruction"},
		          {id:2,name:"Mango",image:"./images/M1.jpg",type:"F",desc:"Description under contruction"},
		          {id:3,name:"beans",image:"./images/V1.jpg",type:"V",desc:"Description under contruction"},
		          {id:4,name:"carrot",image:"./images/V2.jpg",type:"V",desc:"Description under contruction"},
		          {id:5,name:"CauliFlower",image:"./images/V3.jpg",type:"V",desc:"Description under contruction"}
		             );
		return {
			
			getFruit:function()
			{
				var result=new Array();
				
					for(var i in list)
						{
						if(list[i].type=="F")
							{
							result.push(list[i]);
							}
						}
					
					return result;
				
				
			},
			
			getVegetables:function()
			{
				var result=new Array();
				
				for(var i in list)
						{
						if(list[i].type=="V")
							{
							result.push(list[i]);
							}
						}
					
					return result;
				
				
			},
			getFood:function(id)
			{
				var result={};
				for(var i in list)
					{
					if(list[i].id==id)
						{
						result.push(list[i]);
						}
					}
				return result;
			}
			
			
		};
	});