package com.capgemini.main;



import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.entities.Product;
import com.capgemini.exception.ProductException;
import com.capgemini.service.IProductService;

public class MainApp {

	public static void main(String[] args) 
	{
	ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
	IProductService service=(IProductService)context.getBean("productService");
	//ADDING
	try{
	int insert=service.addProduct(new Product("Biscuits",10,200));
	  if(insert>0)
	  System.out.println("Data is inserted Successfully"); 
	  else
	  System.out.println("Insert Failed");
		}
	catch (Exception e) 
		{
			throw new ProductException(e.getMessage());
		}
	//List of Products
	List<Product>plist=service.getAllProduct();
	System.out.println("LIST Of PRODUCTS:");
	for(Product p:plist)
	
	{
		System.out.println(p.getId()+"\t"+p.getName()+"\t"+p.getQuantity()+"\t"+p.getPrice());
	}
	
	//Get Product By id

	Product p1=service.getProduct(8);
	System.out.println("Product Details:");
	System.out.println("Product Id:"+p1.getId());
	System.out.println("Product Name:"+p1.getName());
	System.out.println("Product Quantity:"+p1.getQuantity());
	System.out.println("Product Price:"+p1.getPrice());
	
	}

}
