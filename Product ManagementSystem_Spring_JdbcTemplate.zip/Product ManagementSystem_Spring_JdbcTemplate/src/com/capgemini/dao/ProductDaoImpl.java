package com.capgemini.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.capgemini.entities.Product;
import com.capgemini.exception.ProductException;
@Component("productDao")
public class ProductDaoImpl implements IProductDao 
{
	private JdbcTemplate jdbcTemplate;

	public ProductDaoImpl() 
	{
		super();
	}

	public ProductDaoImpl(JdbcTemplate jdbcTemplate) 
	{
		super();
		this.jdbcTemplate = jdbcTemplate;
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public int addProduct(Product product) throws ProductException 
	{int productid=0;
		
	try 
	{
		productid=jdbcTemplate.queryForObject("select product_seq.nextVal from dual",Integer.class);
			
			String sql="insert into ProductDetails values(?,?,?,?)";
			Object[]params=new Object[]{productid,product.getName(),product.getQuantity(),product.getPrice()};
			jdbcTemplate.update(sql,params);
			
			return productid ;
	} 
	catch (Exception e) 
	{
		
		throw new ProductException(e.getMessage());
	}
	}

	@Override
	public void updateProduct(Product product) throws ProductException
	{
		
		try 
		{
				String sql="update ProductDetails set pname=?,pquantity=?,price=? where pid=?";
				Object[]params=new Object[]{product.getName(),product.getQuantity(),product.getPrice(),product.getId()};
				jdbcTemplate.update(sql,params);
				
				
		} 
		catch (Exception e) 
		{
			
			throw new ProductException(e.getMessage());
		}
		

	}

	@Override
	public void removeProduct(int id) throws ProductException 
	{
		try {
			String query="delete from ProductDetails where pid=?";
		jdbcTemplate.update(query,id);
		System.out.println("Remove Successfully");
		} 
		catch (DataAccessException e) 
		{
			throw new ProductException(e.getMessage());
		}
		
		

	}

	@Override
	public Product getProduct(int pid) throws ProductException 
	{
		Product product;
		try {
			String query="Select * from ProductDetails where pid=?";
			product = (Product)jdbcTemplate.queryForObject(query,new ProductMapper(),pid);
		} 
		catch (DataAccessException e) 
		{
			throw new ProductException(e.getMessage());
		}
		if(product==null)
		{
			throw new ProductException("product not found"); 
		}
		return product;
	}

		
	@Override
	public List<Product> getAllProduct() throws ProductException {
		String sql="select * from ProductDetails";
		List<Product>plist=jdbcTemplate.query(sql,new ProductMapper());
		
		
		return plist;
	}

	@Override
	public Product getProduct(String name) throws ProductException 
	{
		String sql="select * from ProductDetails where pname=?";
		Product product=(Product)jdbcTemplate.queryForObject(sql,new ProductMapper(),name);
	
		return product;
	}

	/*@Override
	public List<Product> getProductInRange(float a, float b)
			throws ProductException 
	{ 
		return null;
	}*/

}
