drop table Product;
create table Product
(
id number(10)primary key,
name varchar2(20),
price number(8,2)
);


drop table Student;

create table Student 
(
rollNo number(5)primary key,
name varchar(15),
DOB date
);

select * from Product;

select * from Student;

drop table ProductDetails
create table ProductDetails
(
pid number primary key,
pname varchar2(30),
pquantity number,
price number(8,2)
);
 commit

select * from ProductDetails;

delete from ProductDetails;
select * from ProductDetails where pname='Snacks'; 