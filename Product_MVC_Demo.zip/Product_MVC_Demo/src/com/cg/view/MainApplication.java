package com.cg.view;

import java.util.List;
import java.util.Scanner;

import com.cg.entity.Product;
import com.cg.exception.ProductException;
import com.cg.service.IProductService;
import com.cg.service.ProductServiceImpl;

public class MainApplication {
 private IProductService ser=new ProductServiceImpl();
 Product p2=new Product();
	public void menu()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Your Choice");
		System.out.println("1:= Add Product");
		System.out.println("2:= View All  Product");	
		System.out.println("3:= Get Product By id");
		System.out.println("4:= Get Product  By Name");
		System.out.println("5:= update Product");
		System.out.println("6:= Remove Product");
		
		
		System.out.println("9:= Exit");
		int c=sc.nextInt();
		switch(c)
		{
		case 1: System.out.println("Enter Product name:");
		String s1=sc.next();
		System.out.println("Enter product category:");
		String s2=sc.next();
		System.out.println("emter quantity:");
		int s3=sc.nextInt();
		System.out.println("Enter price");
		int s4=sc.nextInt();
		Product p1=new Product(s1,s2,s3,s4);
		try{
			int id=ser.addProduct(p1);
			System.out.println("Added with id:"+id);
			
		}
		catch(ProductException e)
		{
			System.out.println("no data added");
		}
		catch(Exception e)

		{
			System.out.println(e.getMessage());
			
		}
		break;
		case 3:/******GetProduct*********/
			
			System.out.println("Enter the product Id To retrive Product Info:");
			System.out.println("Product Id:");
			int productid=sc.nextInt();
			try
			{
				p2=ser.getProduct(productid);
				System.out.println("ID:"+p2.getId());
				System.out.println("NAME:"+p2.getName());
				System.out.println("Quantity:"+p2.getQuantity());
				System.out.println("Price:"+p2.getPrice());
				
			
			}
			catch(ProductException e)
			{
				System.out.println("Product NOt Found:"+e.getMessage());
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
			
			break;
			
		case 2: /*****List**********/
			  	List<Product>list=null;
			  	try
			  	{
			  		list=ser.getAllProducts();
			  		System.out.println(list);
			  	}
			  	catch(ProductException e)
			  	{
			  		System.out.println("List is empty");
			  	}
			  	catch (Exception e) {
					System.out.println(e.getMessage());
				}
			
			
			break;
		case 4:/******GetProductBYNAME*********/
		String pname=null;
			System.out.println("Enter the product name To retrive Product Info:");
			System.out.println("Product name:");
			 pname=sc.next();
			try
			{
				p2=ser.getProductByName(pname);
				System.out.println("ID:"+p2.getId());
				System.out.println("NAME:"+p2.getName());
				System.out.println("Quantity:"+p2.getQuantity());
				System.out.println("Price:"+p2.getPrice());
				
			
			}
			catch(ProductException e)
			{
				System.out.println("Product NOt Found:"+e.getMessage());
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
			
			break;
		
			
		case 5:/********Update******/
			System.out.println("Enter Product id to update:");
			int uid=sc.nextInt();
			char reply;
			Product p3=null;

			try
			{
				 p3=ser.getProduct(uid);
				System.out.println("Old Product Name:"+p3.getName());
				reply=sc.next().charAt(0);
				if(reply=='y')
				{
					System.out.println("Enter New Name:");
					String newName=sc.next();
					p3.setName(newName);
					
				}
				System.out.println("Old Product Quantity:"+p3.getQuantity());
				reply=sc.next().charAt(0);
				if(reply=='y')
				{
					System.out.println("Enter New Quantity:");
					int quantity=sc.nextInt();
					p3.setQuantity(quantity);
					
				}
				System.out.println("Old Product Price:"+p3.getPrice());
				reply=sc.next().charAt(0);
				if(reply=='y')
				{
					System.out.println("Enter New Price:");
					int nprice=sc.nextInt();
					p3.setPrice(nprice);
					
				}
				
			}
			catch(ProductException e)
			{
				System.out.println("Product is Not Found:"+e.getMessage());
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
			try
			{
				if(p3!=null)
				{
					ser.updateProduct(p3);
				}
			}
			catch(ProductException e)
			{
				System.out.println("Could't update  product"+e.getMessage());
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}

			
			break;
		case 6 : /***Remove***/ 
			System.out.println("Enter Product id to remove:");
			int rid=sc.nextInt();
			try
			{
				ser.removeProduct(rid);
				System.out.println("Removed SuccessFully");
			}
			catch(ProductException e)
			{
				System.out.println("Could't Remove  product"+e.getMessage());
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
			break;
			
			
		}		
	}

	
	public static void main(String arg[]) throws ProductException
	{
		MainApplication app=new MainApplication();
		while(true)
		{
			app.menu();
		}
	}
}