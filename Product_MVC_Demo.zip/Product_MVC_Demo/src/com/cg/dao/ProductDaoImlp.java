package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.cg.entity.Product;
import com.cg.exception.ProductException;
import com.cg.util.Dbutil;

public class ProductDaoImlp implements IProductDao {
	private EntityManager manager;

	public ProductDaoImlp() 
	{
		super();
		manager=Dbutil.getEntityManager();
	}

	@Override
	public int addProduct(Product product) throws ProductException {
		int pid=0;
		try
		{
			manager.getTransaction().begin();
			manager.persist(product);
			pid=product.getId();
			manager.getTransaction().commit();
	
		}
		catch(Exception e)
		{
			manager.getTransaction().rollback();
			throw new ProductException(e.getMessage());
		}
			return pid;
	}

	@Override
	public Product getProduct(int id) throws ProductException {
Product product=null;
try
{
	manager.getTransaction().begin();
	product=manager.find(Product.class,id);
	manager.getTransaction().commit();
}
catch(Exception e)
{
	e.getMessage();
}
		return product;
	}

	@Override
	public Product getProductByName(String name) throws ProductException {
		Product product=null;
		try
		{
	manager.getTransaction().begin();	
		
	String str="select product from Product product where product.name=:name";
	TypedQuery<Product>query=manager.createQuery(str,Product.class);	
	query.setParameter("name","beans");
 product=query.getSingleResult();
		
		}

		
		catch(Exception e)
		{ 
		
		}
		if(product==null)
		{
			throw new ProductException("No Product to display:::");
		}
		
		return product;

	}

	@Override
	public List<Product> getAllProducts() throws ProductException {
	List <Product>plist=null;
	try
	{
		manager.getTransaction().begin();
		String str="select p from Product p";
		TypedQuery<Product>query=manager.createQuery(str,Product.class);
		plist=query.getResultList();
		manager.getTransaction().commit();
		
	}
	catch(Exception e)
	{
		manager.getTransaction().rollback();
		e.getMessage();
	}
		return plist;
	}

	@Override
	public void updateProduct(Product product) throws ProductException {
		try
		{
			manager.getTransaction().begin();
			manager.merge(product);
			manager.flush();
			manager.getTransaction().commit();
			
		}

	catch(Exception e)
		{ 
		manager.getTransaction().rollback();
		throw new ProductException(e.getMessage());
		}
		
	}

	@Override
	public void removeProduct(int id) throws ProductException {
		try{
			manager.getTransaction().begin();
			Product rp=manager.find(Product.class,id);
			manager.remove(rp);
			manager.getTransaction().commit();
		}
		catch(Exception e)
		{
			manager.getTransaction().rollback();
			throw new ProductException();
		}
	}

}
