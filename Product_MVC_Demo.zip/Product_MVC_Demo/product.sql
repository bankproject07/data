create table Product;
select  * from PRODUCT;
select pro_seq.nextval from dual;


select * from Product;
insert into Product values(pro_seq.nextVal,'MiNote4','Phone',2,15000);
insert into Product values(pro_seq.nextVal,'Apple','Fruit',25,1500);