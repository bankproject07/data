"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var core_2 = require("@angular/core");
var DiretiveComponent = (function () {
    function DiretiveComponent() {
        this.style = 'normal';
        this.weight = 'normal';
        this.size = '40px';
    }
    return DiretiveComponent;
}());
DiretiveComponent = __decorate([
    core_2.Component({
        selector: 'my-app',
        template: "\n         <div [ngStyle]=\"{'font-size': size}\"> This is heading</div> \n                         \n             "
    })
], DiretiveComponent);
exports.DiretiveComponent = DiretiveComponent;
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        declarations: [DiretiveComponent],
        imports: [platform_browser_1.BrowserModule],
        bootstrap: [DiretiveComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map