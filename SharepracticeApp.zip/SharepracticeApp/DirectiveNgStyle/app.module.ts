import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {Component} from '@angular/core';
@Component ({
    selector : 'my-app',
    template: `
         <div [ngStyle]="{'font-size': size}"> This is heading</div> 
                         
             `
   })
export class DiretiveComponent {
   style:string='normal';
   weight:string='normal';
   size:string='40px';
}

@NgModule({
    declarations: [DiretiveComponent],
    imports: [ BrowserModule ],
    bootstrap: [DiretiveComponent]
 })
export class AppModule {}