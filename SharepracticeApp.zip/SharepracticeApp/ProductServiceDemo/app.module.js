"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var http_1 = require("@angular/http");
var Observable_1 = require("rxjs/Observable");
require("rxjs/Rx");
core_1.enableProdMode();
var ProductService = (function () {
    function ProductService(http) {
        this.http = http;
        this.url = "http://localhost:3000/ProductServiceDemo/product.json";
    }
    ProductService.prototype.getListOfProduct = function () {
        return this.http.get(this.url)
            .map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    ProductService.prototype.errorHandler = function (error) {
        console.log(error);
        return Observable_1.Observable.throw(error.json().error || "server Error");
    };
    return ProductService;
}());
ProductService = __decorate([
    core_1.Injectable(),
    __param(0, core_1.Inject(http_1.Http)),
    __metadata("design:paramtypes", [http_1.Http])
], ProductService);
exports.ProductService = ProductService;
var ProductComponent = (function () {
    function ProductComponent(ser) {
        this.ser = ser;
    }
    ProductComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.ser.getListOfProduct().subscribe(function (list) { console.log(list); _this.pro_list = list; }, function (error) { return _this.ermsg = error; });
    };
    return ProductComponent;
}());
ProductComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        templateUrl: './display.html',
        providers: [ProductService]
    }),
    __param(0, core_1.Inject(ProductService)),
    __metadata("design:paramtypes", [ProductService])
], ProductComponent);
exports.ProductComponent = ProductComponent;
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        declarations: [ProductComponent],
        imports: [platform_browser_1.BrowserModule, http_1.HttpModule],
        bootstrap: [ProductComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map