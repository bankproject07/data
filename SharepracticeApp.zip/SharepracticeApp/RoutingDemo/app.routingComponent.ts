import {Component} from '@angular/core';
@Component({
 selector:'my-app',
 template:`
 <ul>
 <li><a [routerLink]="['/product']">Product</a></li>
 <li><a [routerLink]="['/inventory']">Inventory</a></li>
 </ul>
 
 <router-outlet></router-outlet>
 `

})
export class RoutingComponent{}
