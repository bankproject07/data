import {Component} from '@angular/core';
import{Router} from '@angular/router';

@Component({
    selector:'my-app',
    template:`
    <h4> This is Inventory Component </h4>
    <a class="button"  (click) = "onBack()">Back to Products</a>`
})
export class InventoryComponent{

    constructor(private _router: Router){} 
    
       onBack(): void { 
          this._router.navigate(['/product']); 
       } 

}