import{NgModule} from '@angular/core';
import{BrowserModule} from '@angular/platform-browser';
import{ProductComponent}from './product.component';
import{ InventoryComponent} from './invetory.component';
import{RoutingComponent} from './app.routingComponent';
import{RouterModule,Routes} from '@angular/router';

const appRoutes:Routes=[
    {path:"product",component:ProductComponent},
    {path:"inventory",component:InventoryComponent}
];
@NgModule({
declarations:[RoutingComponent,ProductComponent,InventoryComponent],
imports:[BrowserModule,RouterModule.forRoot(appRoutes)],
bootstrap:[RoutingComponent]

})
export class AppModule{}







