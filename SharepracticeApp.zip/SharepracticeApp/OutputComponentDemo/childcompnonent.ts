import{Component ,Input ,Output, EventEmitter} from '@angular/core';

@Component({
    selector:'child-list',
    templateUrl:'./Employeecount.html'
})
export class ChildComponentClass{
choice:string='All';

@Output()
onChageSelection:EventEmitter<String>=new EventEmitter<String>();

    @Input()
    all:number;
  
    @Input()
    male:number;
    @Input()
    female:number;
    onChangeChoice(){
        this.onChageSelection.emit(this.choice);
        console.log(this.choice);
    }

  

}