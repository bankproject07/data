import{NgModule,Component} from '@angular/core';
import{FormsModule} from '@angular/forms'
import{BrowserModule} from '@angular/platform-browser';
import{ChildComponentClass}from './childcompnonent';
import{ParentComponentClass}from'./parentcomponent';
@NgModule({
    declarations:[ParentComponentClass,ChildComponentClass],
    imports:[BrowserModule,FormsModule],
    bootstrap:[ParentComponentClass]
})
export class AppModule{}