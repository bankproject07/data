"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var core_2 = require("@angular/core");
var core_3 = require("@angular/core");
var platform_browser_dynamic_1 = require("@angular/platform-browser-dynamic");
var custom_directive_1 = require("./custom.directive");
core_2.enableProdMode();
var DirectiveComponent = (function () {
    function DirectiveComponent() {
    }
    return DirectiveComponent;
}());
DirectiveComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        template: "<div>\n\t<h1>Custom Directive</h1>\n\t<hr/>\n\t<button myDirective>Directive Component</button>\n\t</div>"
    })
], DirectiveComponent);
exports.DirectiveComponent = DirectiveComponent;
var AppComponent = (function () {
    function AppComponent() {
    }
    return AppComponent;
}());
AppComponent = __decorate([
    core_3.NgModule({
        imports: [platform_browser_1.BrowserModule],
        declarations: [DirectiveComponent, custom_directive_1.CustomDirective],
        bootstrap: [DirectiveComponent]
    })
], AppComponent);
exports.AppComponent = AppComponent;
platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(AppComponent);
//# sourceMappingURL=main.js.map