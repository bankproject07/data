import{Component} from '@angular/core';
import{FormsModule}from '@angular/forms';
@Component({

    selector:'binding-demo',
template:`
    <div>
    <h2>TWO WAY DATA BINDING DEMO</h2> 
    <input type="text" [(ngModel)]='name'/>
    <span [innerText]='greetmessage'> </span>

    <button (click)="greet()">Welcome</button>
    </div>
`

})
export class TwoWayBindingComponent{
    name:string="Cartoon Network";
    greetmessage:string="";
    greet():void{
        this.greetmessage="Welcome to"+this.name;
    }
}
