import {Component} from '@angular/core';
import{FormsModule}from'@angular/forms';
@Component({

    selector:'my-app',
    template:`

            <style> 
            .custom{
                    color:aqua;
                    text-transformation:uppercase;
                   }
            </style>
            <div>
            <h1>Heading of Page:</h1>
            <h3 class='custom'>Template Using inline style sheet</h3>
            </div>
            <div>
            <binding-demo></binding-demo>
            </div>
            `,

            styles: ['h1 {color:blue}']  




})

export class StyleComponent {}













