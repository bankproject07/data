import{NgModule,Component} from '@angular/core';
import{BrowserModule} from '@angular/platform-browser';
import{EmployeeCompnent} from './EmployeeComponent';

@Component ({

    selector:'my-app',
    template:`
    <div>
    <list-emp></list-emp>
    </div>
    `

})

export class TrackComponent{}

@NgModule({
declarations:[TrackComponent,EmployeeCompnent],
imports:[BrowserModule],
bootstrap:[TrackComponent]

})
export class AppModule{}