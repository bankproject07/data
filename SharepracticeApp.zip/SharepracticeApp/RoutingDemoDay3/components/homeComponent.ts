import { Component } from "@angular/core";
import { Employee } from "../model/employeemodel";

@Component ({
    template: `<h1> Home Page </h1>
    Employee Name :  {{emp.name}}
    <br/>
    Employee Age :  {{emp.age}}
    `
 })
 export class HomeComponent {
     emp:Employee;
     constructor() {
        this.emp= new Employee();
        this.emp.name="Anil";
        this.emp.age=20;
     }
     
 }
 
 
 

 

 