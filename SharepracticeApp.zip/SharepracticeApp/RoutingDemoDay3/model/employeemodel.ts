export class Employee {
name:string;
age:number;
}