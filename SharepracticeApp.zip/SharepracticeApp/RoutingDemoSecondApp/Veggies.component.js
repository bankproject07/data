"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var VegComponent = (function () {
    function VegComponent() {
        this.veggies = [
            { name: "beans", image: "./RoutingDemoSecondApp/images/V1.jpg" },
            { name: "carrot", image: "./RoutingDemoSecondApp/images/V2.jpg" },
            { name: "CauliFlower", image: "./RoutingDemoSecondApp/images/V3.jpg" }
        ];
    }
    return VegComponent;
}());
VegComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        template: "\n    <div>\n    <h4>Template Vegetables</h4>\n    <ul>\n        <li *ngFor=\"let food of veggies\">\n            <img src=\"{{food.image}}\"/>\n            {{food.name}}\n         </li>\n    </ul>\n    \n    </div>\n    "
    })
], VegComponent);
exports.VegComponent = VegComponent;
//# sourceMappingURL=Veggies.component.js.map