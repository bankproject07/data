import {NgModule} from '@angular/core';
import{BrowserModule} from '@angular/platform-browser';
import{FruitsComponent} from './Fruits.component';
import{VegComponent} from './Veggies.component';
import {RoutnigComponent} from './app.routnigcomponent';
import{PageNotFound}from './app.pagenotfoundComponent';
import{RouterModule,Routes} from '@angular/router';


const appRoutes:Routes=[
    {path:"fruit",component:FruitsComponent},
    {path:"veg",component:VegComponent},
    {path:"**",component:PageNotFound}
];
@NgModule({
    declarations:[RoutnigComponent,FruitsComponent,VegComponent],
    imports:[BrowserModule,RouterModule.forRoot(appRoutes)],
    bootstrap:[RoutnigComponent]
})
export class AppModule{}