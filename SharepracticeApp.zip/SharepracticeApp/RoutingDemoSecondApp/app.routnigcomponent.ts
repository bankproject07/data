import {Component} from '@angular/core';

@Component({

    selector:'my-app',
    template:`
    <div>
    <ul>
        <li><a [routerLink]="['/fruit']">List Of Fruits</a></li>
        <li><a [routerLink]="['/veg']">List Of Vegetables</a></li>
    </ul>
    <router-outlet> </router-outlet>
    </div>
    `
})
export class RoutnigComponent{}