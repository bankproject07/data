"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var PhotosliderComponent = (function () {
    function PhotosliderComponent() {
        this.listPhotos = ["./Photoslider/download.jpg", "./Photoslider/images.jpg", "./Photoslider/images (1).jpg"];
        this.location = 0;
        this.photoUrl = this.listPhotos[this.location];
    }
    PhotosliderComponent.prototype.Previous = function () {
        if (this.listPhotos.length > this.location) {
            this.location = this.location - 1;
            this.photoUrl = this.listPhotos[this.location];
        }
    };
    PhotosliderComponent.prototype.Next = function () {
        if (this.listPhotos.length > this.location) {
            this.location = this.location + 1;
            this.photoUrl = this.listPhotos[this.location];
        }
    };
    return PhotosliderComponent;
}());
PhotosliderComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        template: "\n<div><h1>Photo Slider</h1>\n\n    <img [src]='photoUrl'alt='Picture not avilable'/>\n    <button (click)=\"Previous()\" value=\"PRE\">Previous</button>\n\n    <button (click)=\"Next()\" value=\"PRE\">Next</button>\n</div>\n"
    })
], PhotosliderComponent);
exports.PhotosliderComponent = PhotosliderComponent;
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        declarations: [PhotosliderComponent],
        imports: [platform_browser_1.BrowserModule],
        bootstrap: [PhotosliderComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map