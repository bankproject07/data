import {NgModule,Component} from '@angular/core';
import{BrowserModule} from '@angular/platform-browser';

@Component({
selector: 'my-app',
template:`
<div><h1>Photo Slider</h1>

    <img [src]='photoUrl'alt='Picture not avilable'/>
    <button (click)="Previous()" value="PRE">Previous</button>

    <button (click)="Next()" value="PRE">Next</button>
</div>
`
})
export class PhotosliderComponent{


    listPhotos :string[]=["./Photoslider/download.jpg","./Photoslider/images.jpg","./Photoslider/images (1).jpg"];
    location:number=0;
    photoUrl:string=this.listPhotos[this.location];


    Previous():void{

        if(this.listPhotos.length >this.location) {
            this.location=this.location-1;
            this.photoUrl=this.listPhotos[this.location];  
        }      
   
    }

        Next():void{
            
                    if(this.listPhotos.length > this.location) {
                        this.location=this.location+1;
                        this.photoUrl=this.listPhotos[this.location];  
                    }      
               

    }
    
}

@NgModule({

declarations:[PhotosliderComponent],
imports:[BrowserModule],
bootstrap:[PhotosliderComponent]



})
export class AppModule{}