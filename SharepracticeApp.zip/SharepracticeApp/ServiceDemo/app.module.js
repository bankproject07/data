"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var core_2 = require("@angular/core");
var EmployeeService = (function () {
    function EmployeeService() {
    }
    EmployeeService.prototype.getAllEmployees = function () {
        return [
            { id: 5085, name: "Todd", salary: 24000 },
            { id: 6050, name: "Jack", salary: 35000 }
        ];
    };
    return EmployeeService;
}());
EmployeeService = __decorate([
    core_1.Injectable()
], EmployeeService);
exports.EmployeeService = EmployeeService;
var TestServiceComponent = (function () {
    function TestServiceComponent(employeeservice) {
        this.employeeservice = employeeservice;
    }
    TestServiceComponent.prototype.ngOnInit = function () {
        this.employees = this.employeeservice.getAllEmployees();
    };
    return TestServiceComponent;
}());
TestServiceComponent = __decorate([
    core_2.Component({
        selector: 'my-app',
        template: " <h1> Employee List </h1>\n<div>\n<table>\n<tr>\n    <th>Id</th>\n    <th>Name</th>\n    <th>Salary</th>\n</tr>\n<tr *ngFor=\"let emp of employees\">\n    <td>{{emp.id}}</td>\n    <td>{{emp.name}}</td>\n    <td>{{emp.salary}}</td>\n</tr>\n</table>\n\n<ul>\n<li *ngFor=\"let employee of employees\"> {{employee.name}} </li>\n</ul>\n</div>\n",
        providers: [EmployeeService]
    }),
    __param(0, core_1.Inject(EmployeeService)),
    __metadata("design:paramtypes", [EmployeeService])
], TestServiceComponent);
exports.TestServiceComponent = TestServiceComponent;
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        declarations: [TestServiceComponent],
        imports: [platform_browser_1.BrowserModule],
        bootstrap: [TestServiceComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map