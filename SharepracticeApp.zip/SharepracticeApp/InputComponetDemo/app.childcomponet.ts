import {Component} from '@angular/core';
import {Input} from '@angular/core';
@Component({
    selector:'c-com',
    templateUrl:'./empolyeeCount.html'
})
export class ChildComponent{
@Input()
    all:number=5;
    @Input()
    male:number=5;
    @Input()
    female:number=5;
}