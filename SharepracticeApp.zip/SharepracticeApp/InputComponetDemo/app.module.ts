import{NgModule} from '@angular/core';
import{Component} from '@angular/core';
import{BrowserModule} from '@angular/platform-browser';
import{BaseClassComponent} from './app.baseecomponent';
import{ChildComponent} from './app.childcomponet';

@NgModule({
    declarations:[BaseClassComponent,ChildComponent],
    imports:[BrowserModule],
bootstrap:[BaseClassComponent]
})
export class AppModule{}