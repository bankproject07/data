"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var BaseClassComponent = (function () {
    function BaseClassComponent() {
        this.employees = [
            { id: 1, name: "Anjulata", gender: "male", location: "Pune" },
            { id: 2, name: "Uma", gender: "female", location: "Banglore" },
            { id: 3, name: "Amit", gender: "male", location: "Pune" },
            { id: 4, name: "Rahul", gender: "male", location: "Pune" },
            { id: 5, name: "Ukti", gender: "female", location: "Banglore" }
        ];
    }
    BaseClassComponent.prototype.getCountOfAll = function () {
        return this.employees.length;
    };
    BaseClassComponent.prototype.getCountOfAllMale = function () {
        return this.employees.filter(function (e) { return e.gender === "male"; }).length;
    };
    BaseClassComponent.prototype.getCountOfAllFemale = function () {
        return this.employees.filter(function (e) { return e.gender === "female"; }).length;
    };
    return BaseClassComponent;
}());
BaseClassComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        templateUrl: "./display.html"
    })
], BaseClassComponent);
exports.BaseClassComponent = BaseClassComponent;
//# sourceMappingURL=app.baseecomponent.js.map