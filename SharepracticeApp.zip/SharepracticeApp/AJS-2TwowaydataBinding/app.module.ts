import {Component}from '@angular/core';
import{NgModule} from '@angular/core';
import{FormsModule} from '@angular/forms';
import {BrowserModule} from '@angular/platform-browser';


@Component({

    selector:'my-app',
    template:`
   <!-- Name:<input [value]='name' (input)='name=$event.target.value'/>-->
   Name:<input [(ngModel)]='name'/>
    You entered:{{name}}
    
    `
})

export class TwoWayBinding  
{
    name:string="Angualr";
}
@NgModule({
    declarations:[TwoWayBinding],
    imports:[BrowserModule,FormsModule],
    bootstrap:[TwoWayBinding]  
        
})
export class AppModule{}