import {Component} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';

@Component({

    selector:'list-emp',
    templateUrl:'./employee.html'
})
export class EmployeeComponent{
employees:any[]=[

    {id:1,name:"Anjulata",gender:"male",location:"Pune"},
    {id:2,name:"Uma",gender:"female",location:"Banglore"},
    {id:3,name:"Amit",gender:"male",location:"Pune"},
    {id:4,name:"Rahul",gender:"male",location:"Pune"}
]

getEmpolyees():void{

    
this.employees=
[
    {id:1,name:"Anjulata",gender:"male",location:"Pune"},
    {id:2,name:"Uma",gender:"female",location:"Banglore"},
    {id:3,name:"Amit",gender:"male",location:"Pune"},
    {id:4,name:"Rahul",gender:"male",location:"Pune"},
    {id:5,name:"Ukti",gender:"female",location:"Banglore"}
   ]

}


}