"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var forms_1 = require("@angular/forms");
var forms_2 = require("@angular/forms");
var AppComponentClass = (function () {
    function AppComponentClass() {
        this.userForm = new forms_2.FormGroup({
            name: new forms_2.FormControl('XYZ', [forms_2.Validators.required, forms_2.Validators.minLength(4), forms_2.Validators.maxLength(10)]),
            email: new forms_2.FormControl(),
            address: new forms_2.FormGroup({
                street: new forms_2.FormControl(),
                city: new forms_2.FormControl(),
                postalcode: new forms_2.FormControl(null, forms_2.Validators.pattern('^[1-9][0-9]{4}$'))
            })
        });
    }
    AppComponentClass.prototype.OnSubmit = function () {
        console.log(this.userForm.value);
    };
    return AppComponentClass;
}());
AppComponentClass = __decorate([
    core_1.Component({
        selector: 'my-app',
        templateUrl: './component.html',
        styles: ["input.ng-invalid{border-left:5px solid red;}\n    input.ng-valid{border-left:5px solid green;}"]
    })
], AppComponentClass);
exports.AppComponentClass = AppComponentClass;
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        declarations: [AppComponentClass],
        imports: [platform_browser_1.BrowserModule, forms_1.ReactiveFormsModule],
        bootstrap: [AppComponentClass]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map