import {Component} from '@angular/core';
@Component({
    selector:'my-emp',
    templateUrl:'./employee.html'
})


export class EmployeeComponent{

firstName:string="Tom";
gender:string="male";
salary:number=20000;

}