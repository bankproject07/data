"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var forms_1 = require("@angular/forms");
var forms_2 = require("@angular/forms");
var AppComponentClass = (function () {
    function AppComponentClass(formBuilderVar) {
        this.formBuilderVar = formBuilderVar;
    }
    AppComponentClass.prototype.nfOnInit = function () {
        this.useForm = this.formBuilderVar.group({
            name: ['ABC', [forms_2.Validators.required, forms_2.Validators.minLength(4), forms_2.Validators.maxLength(10)]],
            email: [],
            address: this.formBuilderVar.group({
                street: [],
                city: [],
                postalcode: [null, forms_2.Validators.pattern('^[1-9][0-9]{4}$')]
            })
        });
    };
    /* userForm=new FormGroup({
 
         name:new FormControl('XYZ', [Validators.required,Validators.minLength(4),Validators.maxLength(10)]),
         email:new FormControl(),
         address:new FormGroup({
 
             street:new FormControl(),
             city:new FormControl(),
             postalcode:new FormControl(null,Validators.pattern('^[1-9][0-9]{4}$'))
         })
         
     });
 */
    AppComponentClass.prototype.OnSubmit = function () {
        console.log(this.useForm.value);
    };
    return AppComponentClass;
}());
AppComponentClass = __decorate([
    core_1.Component({
        selector: 'my-app',
        templateUrl: './component.html',
        styles: ["input.ng-invalid{border-left:5px solid red;}\n    input.ng-valid{border-left:5px solid green;}"]
    }),
    __metadata("design:paramtypes", [forms_2.FormBuilder])
], AppComponentClass);
exports.AppComponentClass = AppComponentClass;
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        declarations: [AppComponentClass],
        imports: [platform_browser_1.BrowserModule, forms_1.ReactiveFormsModule],
        bootstrap: [AppComponentClass]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map