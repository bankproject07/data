import{Component} from '@angular/core';

@Component({

selector:'my-app',
template:`
<div><my-emp> </my-emp></div>



`

})
export class AppComponent{
    onClick():void{
        console.log('Button');
    }
}