import {Component} from '@angular/core';

@Component({

selector:'my-emp',
templateUrl:`./employee.html`


})
export class EmployeeComponent{

    columnspan:number=2;
    firstname:String='Tom';
    lastname:String='Hopkins';
    salary:number=20000;
    showDetails:boolean=false;


    toggleDetails():void{
        this.showDetails=!this.showDetails;
    }
}