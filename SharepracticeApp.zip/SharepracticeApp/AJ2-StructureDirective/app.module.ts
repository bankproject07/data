import{NgModule}from '@angular/core';
import{BrowserModule} from '@angular/platform-browser';
import{FormsModule} from '@angular/forms';
import{Component} from '@angular/core';
import{EmployeeCompnent} from './EmpolyeeComponent'

@Component({

    selector:'my-app',
    template:
    `<div>
    <list-emp> </list-emp>
    </div>
`

})
export class SecondComponent{}

@NgModule({
    declarations:[SecondComponent,EmployeeCompnent],
    imports:[BrowserModule,FormsModule],
    bootstrap:[SecondComponent]
})

export class AppModule{}