import {NgModule,Input, ChangeDetectionStrategy} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {Component} from '@angular/core';

@Component({
  selector: 'inner-app',
  template:`
      <div>
      <h1> Change Detection- Inner Component </h1>
    <p> {{employeeObj.name}} </p>
     <div>
  `,
  //changeDetection: ChangeDetectionStrategy.Default
  changeDetection: ChangeDetectionStrategy.OnPush
})


export class InnerComponent  {

    @Input() employeeObj:any;

}

@Component ({
    selector : 'my-app',
    template: `
          <div>
          <inner-app  [employeeObj]="employee"> </inner-app>
          <hr/>
          <button (click)="changeProperty()"> Change Property </button>
          <button (click)="changeObject()"> Change Object </button>
          </div>
    
             `
   })
export class MainComponent {
  employee : {id:number,name:string};
  constructor() {
      this.employee={id:101, name: 'Anil'};
  }
   changeProperty():void {
     this.employee.name="Ganesh";
   } 
   changeObject() {
       this.employee={id:102, name:'Karthik'}
   }
 }

@NgModule({
    declarations: [MainComponent,InnerComponent],
    imports: [ BrowserModule ],
    bootstrap: [MainComponent]
 })
export class AppModule {}