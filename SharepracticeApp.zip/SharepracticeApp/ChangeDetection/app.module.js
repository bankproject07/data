"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var core_2 = require("@angular/core");
var InnerComponent = (function () {
    function InnerComponent() {
    }
    return InnerComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], InnerComponent.prototype, "employeeObj", void 0);
InnerComponent = __decorate([
    core_2.Component({
        selector: 'inner-app',
        template: "\n      <div>\n      <h1> Change Detection- Inner Component </h1>\n    <p> {{employeeObj.name}} </p>\n     <div>\n  ",
        //changeDetection: ChangeDetectionStrategy.Default
        changeDetection: core_1.ChangeDetectionStrategy.OnPush
    })
], InnerComponent);
exports.InnerComponent = InnerComponent;
var MainComponent = (function () {
    function MainComponent() {
        this.employee = { id: 101, name: 'Anil' };
    }
    MainComponent.prototype.changeProperty = function () {
        this.employee.name = "Ganesh";
    };
    MainComponent.prototype.changeObject = function () {
        this.employee = { id: 102, name: 'Karthik' };
    };
    return MainComponent;
}());
MainComponent = __decorate([
    core_2.Component({
        selector: 'my-app',
        template: "\n          <div>\n          <inner-app  [employeeObj]=\"employee\"> </inner-app>\n          <hr/>\n          <button (click)=\"changeProperty()\"> Change Property </button>\n          <button (click)=\"changeObject()\"> Change Object </button>\n          </div>\n    \n             "
    }),
    __metadata("design:paramtypes", [])
], MainComponent);
exports.MainComponent = MainComponent;
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        declarations: [MainComponent, InnerComponent],
        imports: [platform_browser_1.BrowserModule],
        bootstrap: [MainComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map