package com.springandangular.service;

import java.util.List;

import com.springandangular.bean.Country;

public interface ICountryService {
	public List<Country>getAllCountries();
	public void addCountry(Country country);
	public Country removeCountry(int id);

}
