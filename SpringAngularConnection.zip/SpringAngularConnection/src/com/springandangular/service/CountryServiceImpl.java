package com.springandangular.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springandangular.bean.Country;
import com.springandangular.dao.CountryDaoImpl;
import com.springandangular.dao.ICountryDao;
@Service
public class CountryServiceImpl  implements ICountryService{
	@Autowired
ICountryDao dao;

	@Override
	public List<Country> getAllCountries() {
	
		return dao.getAllCountries();
	}

	@Override
	public void addCountry(Country country) {
		dao.addCountry(country);
		
	}

	@Override
	public Country removeCountry(int id) {
		
		return dao.removeCountry(id);
	}

}
