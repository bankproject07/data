package com.springandangular.test;

import java.util.ArrayList;
import java.util.List;

import com.springandangular.bean.Country;
import com.springandangular.dao.CountryDaoImpl;
import com.springandangular.service.CountryServiceImpl;
import com.springandangular.service.ICountryService;

public class Test {
ICountryService service=new CountryServiceImpl();
public void getList(){

	List<Country> list=new ArrayList<>();
	list=service.getAllCountries();
	System.out.println(list);

}

public static void main(String arg[])
{
Test t1=new Test();
t1.getList();
}
}
