package com.springandangular.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.springandangular.bean.Country;
import com.springandangular.util.Database;
@Repository
public class CountryDaoImpl implements ICountryDao{

	@Override
	public List<Country> getAllCountries() {
	System.out.println("Inside Dao:");
	/*List<Country>list=new ArrayList<>();
	list=Database.getCountryList();
	System.out.println(list);*/
		return Database.getCountryList();
	}

	@Override
	public void addCountry(Country country) 
	{
		Database.getCountryList().add(country);
	}

	@Override
	public Country removeCountry(int id) 
	{
		
		return Database.getCountryList().remove(id);
	}

}
