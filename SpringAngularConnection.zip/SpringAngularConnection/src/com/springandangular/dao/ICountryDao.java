package com.springandangular.dao;

import java.util.List;

import com.springandangular.bean.Country;

public interface ICountryDao {
	public List<Country>getAllCountries();
	public void addCountry(Country country);
	public Country removeCountry(int id);


}
