package com.springandangular.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;




import org.springframework.web.bind.annotation.RestController;

import com.springandangular.bean.Country;
import com.springandangular.service.ICountryService;
@RestController
public class SpringController {
	@Autowired
	 ICountryService service;
	
	@RequestMapping(value="/countries",
			method=RequestMethod.GET,
			headers="Accept=application/json" )
	public List<Country>getAllCountry(Model model)
	{
		/*System.out.println("Inside Controller::");
		List<Country>clist=new ArrayList<>();
		clist=service.getAllCountries();
		model.addAttribute("dataList",clist);
		System.out.println(clist);
*/	
		return service.getAllCountries();
	}	
	
	
	@RequestMapping(value="countries/create/{id}/{name}/{popu}",method = RequestMethod.POST,headers="Accept=application/json")
	public List<Country>createCountry(@PathVariable int id,@PathVariable String name,@PathVariable int popu)
	{
	Country country=new Country();
	country.setCountryId(id);
	country.setCountryName(name);
	country.setPopulation(popu);
	
		service.addCountry(country);
		return service.getAllCountries();
	
	}
	
	
	@RequestMapping(value="/countries/delete/{id}",method=RequestMethod.DELETE,headers="application/json")
	public List<Country>deleteCountry(@PathVariable int id)
	{
		service.removeCountry(id);
		return service.getAllCountries();
	}

}
/*
	
*/