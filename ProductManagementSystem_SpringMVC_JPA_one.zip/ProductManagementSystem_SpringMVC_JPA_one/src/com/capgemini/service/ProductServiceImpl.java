package com.capgemini.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.IProductDAO;
import com.capgemini.dao.ProductDAOImpl;
import com.capgemini.entity.Product;
import com.capgemini.exception.ProductException;

@Transactional
@Service("productService")
public class ProductServiceImpl implements IProductService 
{
	
	@Autowired
	private IProductDAO productDAO;
	
	public ProductServiceImpl()
	{   }
	

	public IProductDAO getProductDAO() {
		return productDAO;
	}


	public void setProductDAO(IProductDAO productDAO) {
		this.productDAO = productDAO;
	}


	public ProductServiceImpl(IProductDAO productDAO) {
		super();
		this.productDAO = productDAO;
	}


	@Override
	public int addProduct(Product product) throws ProductException {
		
		return productDAO.addProduct(product);
	}

	@Override
	public void updateProduct(Product product) throws ProductException {
		
		productDAO.updateProduct(product);

	}

	@Override
	public Product getProduct(int id) throws ProductException {
		
		return productDAO.getProduct(id);
	}

	@Override
	public void removeProduct(int id) throws ProductException {

		productDAO.removeProduct(id);

	}

	@Override
	public List<Product> getAllProducts() throws ProductException {


		return productDAO.getAllProducts();
	}

	@Override
	public Product getProductDetails(String name) throws ProductException {
		
		return productDAO.getProductDetails(name);
	}

	@Override
	public List<Product> getProductRange(float min, float max)
			throws ProductException {
		
		return productDAO.getProductRange(min, max);
	}

	
	

}
