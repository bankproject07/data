package com.capgemini.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.entity.Product;
import com.capgemini.exception.ProductException;


@Repository("productDAO")
public class ProductDAOImpl implements IProductDAO {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public ProductDAOImpl()
	{
		
	}

	@Override
	public int addProduct(Product product) throws ProductException {
		
		int productId = 0;
		try
		{			
			
			entityManager.persist(product);
			
			productId = product.getId();
			
		
			
		}
		catch(Exception e)
		{			
			throw new ProductException(e.getMessage());
		}
		return productId;
	}

	@Override
	public void updateProduct(Product product) throws ProductException {
		
		try
		{
						
			entityManager.merge(product);
			entityManager.flush();
						
		}
		catch(Exception e)
		{
			
			
			
			throw new ProductException(e.getMessage());
		}
	
		

	}

	@Override
	public Product getProduct(int id) throws ProductException {
		
		Product product = null;
		try
		{
			
			product =  entityManager.find(Product.class, id);
		
		}
		catch(Exception e)
		{
			
		
			
			throw new ProductException(e.getMessage());
		}
	
		if(product == null)
			throw new ProductException("No Product Found with id " + id);
		
		return product;
	}

	@Override
	public void removeProduct(int id) throws ProductException {
		
		try
		{
			
			
			
			Product product = entityManager.find(Product.class, id);
			
			entityManager.remove(product);
			
			
			
		}
		catch(Exception e)
		{
			
			
			
			throw new ProductException(e.getMessage());
		}
	

	}

	@Override
	public List<Product> getAllProducts() throws ProductException {
		
		List<Product> products = null;
		try
		{
						
			TypedQuery<Product> tQuery = 
					entityManager.createNamedQuery("GetAllProducts" , Product.class);
			
			products = tQuery.getResultList();
		
		}
		catch(Exception e)
		{
			throw new ProductException(e.getMessage());
		}
		
		if(products == null  || products.isEmpty() )
			throw new ProductException("No Products to display");
		
		return products;
	}

	@Override
	public Product getProductDetails(String name) throws ProductException {
		
		Product productdetail = null;
		try
		{
			
			EntityTransaction transaction = entityManager.getTransaction();
			
		
			
			TypedQuery<Product> tQuery = 
					entityManager.createQuery("select p from Product p where p.name =:pname" , Product.class);
			
			tQuery.setParameter("pname", name);
			
			productdetail = tQuery.getSingleResult();
			
			transaction.commit();
			
		}
		catch(Exception e)
		{
			
			entityManager.getTransaction().rollback();
			
			throw new ProductException(e.getMessage());
		}
	
		if(productdetail == null)
			throw new ProductException("No Product Found with name " + name);
		
		return productdetail;
	}

	@Override
	public List<Product> getProductRange(float min, float max)
			throws ProductException {
		
		List<Product> productRange = null;
		try
		{
			
			EntityTransaction transaction = entityManager.getTransaction();
			
			transaction.begin();
			
			TypedQuery<Product> tQuery = 
					entityManager.createNamedQuery("GetPriceRange" , Product.class);
			
			tQuery.setParameter("min", min);
			tQuery.setParameter("max", max);
			
			productRange = tQuery.getResultList();
			
			transaction.commit();
			
		}
		catch(Exception e)
		{
			
			entityManager.getTransaction().rollback();
			
			throw new ProductException(e.getMessage());
		}
	
		if(productRange == null || productRange.isEmpty())
			
			throw new ProductException(" Invalid Range ");
		
		return productRange;
	}
	
	}




