package com.capgemini.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.entity.Product;
import com.capgemini.service.IProductService;


@Controller
public class ProductControllor {


	@Autowired
	IProductService productService;

	public ProductControllor(IProductService productService) {
		super();
		this.productService = productService;
	}

	public ProductControllor() {
		super();
	}

	public IProductService getProductService() {
		return productService;
	}

	public void setProductService(IProductService productService) {
		this.productService = productService;
	}

	//provide home page
	@RequestMapping("home")
	public String getHomePage()
	{
		return "HomePage";
	}

	//initalizing AddProduct jsp
	@RequestMapping("addproduct")
	public String getAddproductPage(Model model)
	{
		//init data for category drop down list
		List<String>categories = new ArrayList<>();
		categories.add("Shoes");
		categories.add("Electronics");
		categories.add("Books");
		categories.add("HomeTools");
		categories.add("Furniture");

		//Add the form backing bean to be  binded to AddProduct.jsp
		model.addAttribute("product", new Product());


		//Add categories to build drop down list
		model.addAttribute("categories", categories);

		//Return to view
		return "AddProductPage";

	}

	@RequestMapping(value="ProcessAddProductForm")
	public ModelAndView processAddProductForm(
			@ModelAttribute("product") @Valid Product product, 
			BindingResult result, 
			Model model)
	{

		if(result.hasErrors() == true)
		{
			//init data for category drop down list
			List<String>categories = new ArrayList<>();
			categories.add("Shoes");
			categories.add("Electronics");
			categories.add("Books");
			categories.add("HomeTools");
			categories.add("Furniture");

			//Add the form backing bean to be  binded to AddProduct.jsp
			model.addAttribute("product", product);


			//Add categories to build drop down list
			model.addAttribute("categories", categories);


			return new ModelAndView("AddProductPage");
		}

		int productid= -1;

		try 
		{

			productid = productService.addProduct(product);
			model.addAttribute("message", "Product added Successfully. Product Id: "
					+ productid);

			return new ModelAndView("SuccessPage");


		} catch (Exception e) 
		{

			model.addAttribute("errMsg", "Could not found product. Reason "
					+ e.getMessage());

			return new ModelAndView("ErrorPage");

		}

	}
	@RequestMapping("getproduct")
	public String getProductPage()
	{
		return "GetProductPage";
	}


	@RequestMapping("processgetproductform")
	public ModelAndView processGetProductForm(@RequestParam("productId") int pid)
	{
		Product product = null;
		System.out.println("In");
		try 
		{
			product = productService.getProduct(pid);
			System.out.println(product);
			return new ModelAndView("GetProductPage","product",product);


		} catch (Exception e) {

			return new ModelAndView("ErrorPage", "errMsg",
					"Could not retrieve the product. Reason: " +
							e.getMessage());
		}

	}

	@RequestMapping("viewallproducts")
	public String getViewAllProductsPage(Model model)
	{
		List<Product> products;

		System.out.println("hello");
		try 
		{
			products = productService.getAllProducts();
			model.addAttribute("products", products);
		} 
		catch (Exception e)
		{
			model.addAttribute("errMsg","Could Not Display Products. Reason: "
					+e.getMessage());

			return "ErrorPage";
		}

		return "ViewAllProductPage";
	}
	
	@RequestMapping("getupdatepage")
	public String getUpdatePage(@RequestParam("pid") int id, Model model)
	{
		//init data for category drop down list
				List<String>categories = new ArrayList<>();
				categories.add("Shoes");
				categories.add("Electronics");
				categories.add("Books");
				categories.add("HomeTools");
				categories.add("Furniture");
				
				Product product = null;
				
				try 
				{
					product = productService.getProduct(id);
				} 
				catch (Exception e)
				{
					model.addAttribute("errMsg", "Could not retrieve Product Details Reason: "+e.getMessage());
					return "ErrorPage";
				}

				//Add the form backing bean to be  binded to AddProduct.jsp
				model.addAttribute("product", product);


				//Add categories to build drop down list
				model.addAttribute("categories", categories);

				//Return to view
		return "UpdatePage";
	}
	@RequestMapping(value="processupdatepageform", method=RequestMethod.POST)
	public String processUpdatePageForm(@ModelAttribute("product") @Valid Product product,
			BindingResult result, Model model)
			{
		if(result.hasErrors() == true)
		{
			//init data for category drop down list
			List<String>categories = new ArrayList<>();
			categories.add("Shoes");
			categories.add("Electronics");
			categories.add("Books");
			categories.add("HomeTools");
			categories.add("Furniture");

			//Add the form backing bean to be  binded to AddProduct.jsp
			model.addAttribute("product", product);


			//Add categories to build drop down list
			model.addAttribute("categories", categories);



			return "UpdatePage";
		}
		try 
		{
			productService.updateProduct(product);
		} 
		catch (Exception e) 
		{
				model.addAttribute("errMsg","Could not update product details. Reason:"+e.getMessage());
				return "ErrorPage";
		}
		model.addAttribute("message","Product Updated Successfully");
			return "SuccessPage";
			}

























}
