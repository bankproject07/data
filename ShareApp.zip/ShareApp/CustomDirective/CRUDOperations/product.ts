export interface IProduct{
    productId:number,productName:String;
}