import{Component} from '@angular/core';
import{IProduct} from './product';
import{ProductService} from'./product.service';
import{Http ,Response} from '@angular/http';
import{Observable} from 'rxjs/Observable';
import'rxjs/add/operator/map';


@Component({
    selector:'my-app',
    template:` <div> Hello </div>`,
    providers:[ProductService]

})
export class AppComponent{
    iproduct:IProduct[];
    constructor(private product:ProductService){}
    ngOnInit():void{
        this.product.getProduct()
        .subscribe(iproduct=> this.iproduct=iproduct)    }
}