import{Component} from '@angular/core';

@Component({


    selector:'list-emp',
    templateUrl:'./empolyee.html'
})
export class EmployeeCompnent
{
employees:any[]=[
    {id:1,name:"Anjulata",location:"Pune"},
    {id:2,name:"Uma",location:"Banglore"},
    {id:3,name:"Amit",location:"Pune"},
    {id:4,name:"Rahul",location:"Pune"},
    {id:5,name:"Ukti",location:"Banglore"},
    {id:6,name:"Bharti",location:"Mumbai"},
    {id:7,name:"kavita",location:"Mumbai"},
    {id:8,name:"Hema",location:"Chenai"},
    {id:9,name:"Tanmaya",location:"Banglore"},
    {id:10,name:"Vaishali",location:"Pune"},
]

}