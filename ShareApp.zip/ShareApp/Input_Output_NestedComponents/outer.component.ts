import { Component } from '@angular/core';
import { InnerComponent } from './inner.component';

@Component({
	selector: 'my-app',
	template:`
	            <my-directive [receiveAlternate]="details" (myevent)="onMyEvent($event)"></my-directive>
                <br>
				Data received - {{messagefromnested}}
		 `
})


export class OuterComponent {
	messagefromnested:string="";
	details = {
		msg:'Message Initially sent from Outer Component to Inner Component'
	}
	
	onMyEvent(greet:any){
		this.messagefromnested = "Message Received from Inner Component : "+ greet;
	}
}