import { BrowserModule } from '@angular/platform-browser';
import { NgModule,enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { InnerComponent } from './inner.component';
import { OuterComponent } from './outer.component';

@NgModule({
  imports:[ BrowserModule ],
  declarations:[ OuterComponent,InnerComponent ],
  bootstrap:[ OuterComponent ]
})
export class AppModule{}

