import { Component } from "@angular/core";

@Component ({
    selector:'my-app',
    template: ` <div> 
       <div>
          <a [routerLink]="['/home']"> Home </a>
          <a [routerLink]="['/about',id]"> About </a>
       </div>
       <div>
             <router-outlet> </router-outlet>
       </div>
     </div>
    `
 })
export class AppComponent {
    id:number=100;
 }