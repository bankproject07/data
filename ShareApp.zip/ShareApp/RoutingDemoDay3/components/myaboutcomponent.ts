import { Component, Inject } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";


@Component({
    templateUrl:'./aboutcomponent_template.html'    
 })
export class AboutComponent {
    private id:number;
    constructor(@Inject(ActivatedRoute) private route:ActivatedRoute, @Inject(Router) private router:Router )
    {
        this.id= parseInt(route.snapshot.params['id']);
    }
    navigateToHome():void {

        this.router.navigate(['/home']);
    }
 }