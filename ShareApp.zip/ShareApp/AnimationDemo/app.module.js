"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var animations_1 = require("@angular/platform-browser/animations");
var animations_2 = require("@angular/animations");
var animationComponent = (function () {
    function animationComponent() {
    }
    return animationComponent;
}());
animationComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        templateUrl: './animationPage.html',
        styles: ["\n\ndiv{\n    margin:0 auto;\n    text-align:center;\n    width:200px;\n}\n.rotate{\n    width:100px;\n    height:100px;\n    border:solid 1px red;\n}"],
        animations: [
            animations_2.trigger('myanimation', [
                animations_2.state('smaller', animations_2.style({
                    transform: 'translateY(100px)'
                })),
                animations_2.state('larger', animations_2.style({
                    transform: "translateY(0px)"
                })),
                animations_2.transition('smaller<=>larger', animations_2.animate('500ms ease-in'))
            ])
        ]
    })
], animationComponent);
exports.animationComponent = animationComponent;
var AppModule = (function () {
    function AppModule() {
        this.state = "smaller";
    }
    AppModule.prototype.animate = function () {
        this.state = this.state == 'larger' ? 'smaller' : 'larger';
    };
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        declarations: [animationComponent],
        imports: [platform_browser_1.BrowserModule, animations_1.BrowserAnimationsModule],
        bootstrap: [animationComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map