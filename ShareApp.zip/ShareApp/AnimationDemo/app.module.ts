import{NgModule,Component}from'@angular/core';
import{BrowserModule}from '@angular/platform-browser';
import{BrowserAnimationsModule}from '@angular/platform-browser/animations';
import { trigger, state, style, transition, animate } from '@angular/animations';

@Component({
selector:'my-app',
templateUrl:'./animationPage.html',
styles:[`

div{
    margin:0 auto;
    text-align:center;
    width:200px;
}
.rotate{
    width:100px;
    height:100px;
    border:solid 1px red;
}`],

animations:[

    trigger('myanimation',[
        state('smaller',style({
            transform:'translateY(100px)'
        })),
        state('larger',style({
            transform:"translateY(0px)"
        })),
        transition('smaller<=>larger',animate('500ms ease-in'))
    ])
]

})
export class animationComponent{}
@NgModule({
declarations:[animationComponent],
imports:[BrowserModule,BrowserAnimationsModule],
bootstrap:[animationComponent]


})
export class AppModule{

    state:string="smaller";
    animate(){
        this.state=this.state=='larger'?'smaller':'larger';

    }
}