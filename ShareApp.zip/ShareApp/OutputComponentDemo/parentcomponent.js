"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var ParentComponentClass = (function () {
    function ParentComponentClass() {
        this.defaultChoice = "Female";
        this.employees = [
            { id: 1, name: "Anjulata", gender: "male", location: "Pune" },
            { id: 2, name: "Uma", gender: "female", location: "Banglore" },
            { id: 3, name: "Amit", gender: "male", location: "Pune" },
            { id: 4, name: "Rahul", gender: "male", location: "Pune" },
            { id: 5, name: "Ukti", gender: "female", location: "Banglore" }
        ];
    }
    ParentComponentClass.prototype.onRadioButtonChange = function (newChoice) {
        this.defaultChoice = newChoice;
    };
    ParentComponentClass.prototype.getCountEmployees = function () {
        return this.employees.length;
    };
    ParentComponentClass.prototype.getCountMaleEmployee = function () {
        return this.employees.filter(function (a) { return a.gender === "male"; }).length;
    };
    ParentComponentClass.prototype.getCountFemaleEmployee = function () {
        return this.employees.filter(function (a) { return a.gender === "female"; }).length;
    };
    return ParentComponentClass;
}());
ParentComponentClass = __decorate([
    core_1.Component({
        selector: 'my-app',
        templateUrl: "./Display.html"
    })
], ParentComponentClass);
exports.ParentComponentClass = ParentComponentClass;
//# sourceMappingURL=parentcomponent.js.map