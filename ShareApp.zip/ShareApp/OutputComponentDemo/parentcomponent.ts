import{Component} from '@angular/core';
@Component({
    selector:'my-app',
    templateUrl:`./Display.html`
})

export class ParentComponentClass{
    defaultChoice:string="Female";
    employees:any[]=[
        {id:1,name:"Anjulata",gender:"male",location:"Pune"},
        {id:2,name:"Uma",gender:"female",location:"Banglore"},
        {id:3,name:"Amit",gender:"male",location:"Pune"},
        {id:4,name:"Rahul",gender:"male",location:"Pune"},
        {id:5,name:"Ukti",gender:"female",location:"Banglore"}
    ]

    onRadioButtonChange(newChoice:string):void{
    this.defaultChoice=newChoice;

    }

 getCountEmployees():number
        {
        return this.employees.length;
}
    getCountMaleEmployee():number{
        return this.employees.filter(a=>a.gender==="male").length;
    }
    getCountFemaleEmployee():number{
        return this.employees.filter(a=>a.gender==="female").length;
    }
}