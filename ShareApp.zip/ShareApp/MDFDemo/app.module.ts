import {NgModule ,Component} from '@angular/core';
import {BrowserModule}from '@angular/platform-browser';
import{ReactiveFormsModule} from '@angular/forms';
import {FormGroup,FormControl, Validators}from '@angular/forms';

@Component({

    selector:'my-app',
    templateUrl:'./component.html',
    styles:[`input.ng-invalid{border-left:5px solid red;}
    input.ng-valid{border-left:5px solid green;}`]

})
export class AppComponentClass{

    userForm=new FormGroup({

        name:new FormControl('XYZ', [Validators.required,Validators.minLength(4),Validators.maxLength(10)]),
        email:new FormControl(),
        address:new FormGroup({

            street:new FormControl(),
            city:new FormControl(),
            postalcode:new FormControl(null,Validators.pattern('^[1-9][0-9]{4}$'))
        })
        
    });


    OnSubmit(){
        console.log(this.userForm.value);
    }



}

@NgModule({
    declarations:[AppComponentClass],
    imports:[BrowserModule,ReactiveFormsModule],
    bootstrap:[AppComponentClass]

})
export class AppModule{}