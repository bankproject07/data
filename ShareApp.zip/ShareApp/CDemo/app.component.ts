import {Component} from'@angular/core';
import{EmployeeComponent}   from './EmployeeComponent/empolyee.component' ;
@Component({
    selector:'my-app',
    template:
    `<div>

    <h3>{{pageHeader}}</h3>
    <my-emp> </my-emp>

    </div>
    
    `

})
export class AppComponent{

    pageHeader:string="Employee Details";

}