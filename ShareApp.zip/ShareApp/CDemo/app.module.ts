import {NgModule} from '@angular/core';
import {Component} from '@angular/core';
import{BrowserModule} from '@angular/platform-browser';
import{EmployeeComponent} from './EmployeeComponent/empolyee.component';
import {AppComponent} from './app.component';


@NgModule({

    declarations:[EmployeeComponent,AppComponent],
    imports:[BrowserModule],
    bootstrap:[AppComponent]

})


export class AppModule{}