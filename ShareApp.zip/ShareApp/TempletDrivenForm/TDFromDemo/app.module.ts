import { NgModule, Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
@Component({
    selector: 'my-app',
    templateUrl:'./component.html',
    styles:[`input.ng-invalid{border-left:5px solid red;}
            input.ng-valid{border-left:5px solid green;}`]
})
export class AppComponent { 
    onSubmit(value:any){
        console.log(value);
    }


}


@NgModule({
    declarations: [AppComponent],
    imports: [BrowserModule, FormsModule],
    bootstrap: [AppComponent]
})
export class AppModule { }