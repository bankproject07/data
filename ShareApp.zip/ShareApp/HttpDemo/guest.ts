export interface IGuest{
    id:number,
    name:string,
    contactNumber:string
}