"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
var http_2 = require("@angular/http");
var platform_browser_1 = require("@angular/platform-browser");
var Observable_1 = require("rxjs/Observable");
require("rxjs/Rx");
var GuestService = (function () {
    function GuestService(http) {
        this.http = http;
        this.url = 'http://localhost:3000/HttpDemo/guests.json';
    }
    GuestService.prototype.getAllGuests = function () {
        return this.http.get(this.url)
            .map(function (response) { return response.json(); }).catch(this.handleError);
    };
    GuestService.prototype.handleError = function (error) {
        console.log(error);
        return Observable_1.Observable.throw(error.json().error || 'Server Error');
    };
    return GuestService;
}());
GuestService = __decorate([
    core_1.Injectable(),
    __param(0, core_1.Inject(http_2.Http)),
    __metadata("design:paramtypes", [http_2.Http])
], GuestService);
exports.GuestService = GuestService;
var GuestComponent = (function () {
    function GuestComponent(service) {
        this.service = service;
    }
    GuestComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.service.getAllGuests()
            .subscribe(function (guests) { console.log(guests); _this.guests_received = guests; }, function (error) { return _this.errorMessage = error; });
    };
    return GuestComponent;
}());
GuestComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        template: "\n  <table class=\"table table-striped\">\n  <thead>\n      <tr>\n          <th>Id</th>\n          <th>Name</th>\n          <th>Contact</th>\n      </tr>\n  </thead>\n  <tbody>\n       <tr *ngFor=\"let guest of guests_received\">\n            <td>{{ guest.id }}</td>\n            <td>{{ guest.name }}</td>\n            <td>{{ guest.contactNumber }}</td>\n        </tr>\n   </tbody>\n</table>\n   \n  ",
        providers: [GuestService]
    }),
    __param(0, core_1.Inject(GuestService)),
    __metadata("design:paramtypes", [GuestService])
], GuestComponent);
exports.GuestComponent = GuestComponent;
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [platform_browser_1.BrowserModule, http_1.HttpModule],
        declarations: [GuestComponent],
        bootstrap: [GuestComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map