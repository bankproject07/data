import{NgModule,Component,Injectable,Inject,OnInit,enableProdMode} from '@angular/core';
import{BrowserModule} from '@angular/platform-browser';
import{HttpModule,Http,Response} from '@angular/http';
import{platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import{Observable} from 'rxjs/Observable';
import 'rxjs/Rx';
enableProdMode();
@Injectable()
export class ProductService{
private url="http://localhost:3000/ProductServiceDemo/product.json";
constructor(@Inject(Http) private http:Http){}

getListOfProduct():Observable<any[ ]>{
return this.http.get(this.url)
                .map((res:Response)=> <any[]>res.json())
                .catch(this.errorHandler);
}

private errorHandler(error:Response){
    console.log(error);
    return Observable.throw(error.json().error ||"server Error")
}

}

@Component({
    selector:'my-app',
    templateUrl:'./display.html',
    providers:[ ProductService ] 
})
export class ProductComponent implements OnInit{

    private pro_list:any[];
    private ermsg:any;

    constructor(@Inject(ProductService) private ser:ProductService){}
    ngOnInit():void{
        this.ser.getListOfProduct().subscribe(

            (list)=>{console.log(list) ;this.pro_list=list},
            (error)=>this.ermsg=error);
    }
}



@NgModule({
    declarations:[ProductComponent],
    imports:[BrowserModule,HttpModule],
    bootstrap:[ProductComponent]
})
export class AppModule{}