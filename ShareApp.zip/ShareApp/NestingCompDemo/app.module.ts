import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import{Component} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {StyleComponent} from './StyleComponent';
import {TwoWayBindingComponent} from './TwoWayBindingComponent';

@NgModule({

   declarations:[StyleComponent,TwoWayBindingComponent],
   imports:[BrowserModule,FormsModule],
   bootstrap:[StyleComponent]
    
})

export class AppModule{}



