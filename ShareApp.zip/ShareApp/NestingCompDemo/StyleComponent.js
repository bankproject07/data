"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var StyleComponent = (function () {
    function StyleComponent() {
    }
    return StyleComponent;
}());
StyleComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        template: "\n\n            <style> \n            .custom{\n                    color:aqua;\n                    text-transformation:uppercase;\n                   }\n            </style>\n            <div>\n            <h1>Heading of Page:</h1>\n            <h3 class='custom'>Template Using inline style sheet</h3>\n            </div>\n            <div>\n            <binding-demo></binding-demo>\n            </div>\n            ",
        styles: ['h1 {color:blue}']
    })
], StyleComponent);
exports.StyleComponent = StyleComponent;
//# sourceMappingURL=StyleComponent.js.map