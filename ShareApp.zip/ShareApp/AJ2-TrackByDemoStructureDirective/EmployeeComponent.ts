
import{Component} from '@angular/core';

@Component({
    selector:'list-emp',
    templateUrl:'./employee.html'
})
export class EmployeeCompnent
{
employees:any[]=[
    {id:1,name:"Anjulata",gender:"male",location:"Pune"},
    {id:2,name:"Uma",gender:"female",location:"Banglore"},
    {id:3,name:"Amit",gender:"male",location:"Pune"},
    {id:4,name:"Rahul",gender:"male",location:"Pune"}
   
   ]

getEmpolyee():void
{
this.employees=
    [
        {id:1,name:"Anjulata",gender:"male",location:"Pune"},
        {id:2,name:"Uma",gender:"female",location:"Banglore"},
        {id:3,name:"Amit",gender:"male",location:"Pune"},
        {id:4,name:"Rahul",gender:"male",location:"Pune"},
        {id:5,name:"Ukti",gender:"female",location:"Banglore"}
       ]
}
 trackById(index:number,employee:any):string
 {
     return employee.id;
 }
}