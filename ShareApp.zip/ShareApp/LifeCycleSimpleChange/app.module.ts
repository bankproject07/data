import{NgModule,Component} from '@angular/core';
import{BrowserModule} from '@angular/platform-browser';
import {FormsModule } from "@angular/forms";
import{SimpleComponentClass}from './aap.component';

@Component({
    selector:'my-app',
    template:`
    <div>
    Your Text:<input type="text"[(ngModel)]="usertext"/><br/><br/>
    <simple [simpletext]="usertext"></simple>
    </div>`
})
export class ComponentClass{
    usertext:string="Cartoon Network";
}



@NgModule({

    declarations:[ComponentClass,SimpleComponentClass],
    imports:[BrowserModule,FormsModule],
    bootstrap:[ComponentClass]
})

export class AppModule{}