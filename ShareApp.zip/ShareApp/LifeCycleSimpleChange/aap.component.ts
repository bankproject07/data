import {Component,Input ,OnChanges,SimpleChanges} from '@angular/core';
@Component({
    selector:'simple',
    template:`
    <div>
    You Entered:{{simpletext}}
    </div>
    `
})
export class SimpleComponentClass implements OnChanges{
    @Input()
    simpletext:string;
   
    ngOnChanges(changeobj:SimpleChanges){
        for(let propertyName in changeobj){
            let change=changeobj[propertyName];
            let current=JSON.stringify(change.currentValue);
            let previous=JSON.stringify(change.previousValue);
            console.log(propertyName +':currentValue='+current+ ',previousvalue =' + previous);
        }
    }
     
   

}