import {NgModule,Component}from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import{FormsModule} from'@angular/forms';

@Component({
selector:'my-app',
template : 

`
<h1> Working of calculator</h1><br/>
Enter first number: <input type="number" [(ngModel)]="firstNumber"/><br/>
Enter Second Number:
<input type="number" [(ngModel)]="secondNumber"/><br/>
<button (click)='add()'>+</button>
<button (click)='sub()'>-</button>
<button (click)='mul()'>*</button>
<button (click)='div()'>/</button><br/>

RESULT:<span>{{total}}</span>

`

})
export class PracticesComponent{
 firstNumber:number;
 secondNumber:number;
 total:number=0;
 
 add():number{
      this.total= this.firstNumber+this.secondNumber;
      return this.total;

      }

      sub():number{
        this.total= this.firstNumber-this.secondNumber;
        return this.total;
  
        }
  

        mul():number{
            this.total= this.firstNumber*this.secondNumber;
            return this.total;
      
            }

            div():number{
                this.total= this.firstNumber/this.secondNumber;
                return this.total;
          
                }
          
}

@NgModule({

    declarations: [PracticesComponent],
    imports: [ BrowserModule ,FormsModule],
    bootstrap: [PracticesComponent]


})
export class AppModule {}