import {NgModule,OnInit,OnDestroy} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {Component} from '@angular/core';

@Component({
  selector: 'on-init',
  template:'<div> Init/Destroy </div>'

})


export class MyComponent implements OnInit, OnDestroy {

    constructor () 
    {
        console.log("MyComponent constructor called");
    }
    ngOnInit() {
        console.log("MyComponent - onInit called");
    }
    ngOnDestroy() {
        //Called once, before the instance is destroyed.
        //Add 'implements OnDestroy' to the class.
        console.log("MyComponent - onDestroy called");
    }

}

@Component ({
    selector : 'my-app',
    template: `
              <h1> Lifecycle demo </h1>
              <h4> OnInit and OnDestroy </h4>
              <button (click)="toggle()"> toggle </button>
              <hr>             
              <on-init  *ngIf="display"> </on-init>            
             `
   })
export class ComponentLifeCycleComponent {
  display:boolean;
  constructor() {
      this.display=true;
  }
  toggle() {
      this.display=!this.display;
  }
    
 }

@NgModule({
    declarations: [ComponentLifeCycleComponent,MyComponent],
    imports: [ BrowserModule ],
    bootstrap: [ComponentLifeCycleComponent]
 })
export class AppModule {}