import{NgModule} from '@angular/core';
import{Component} from'@angular/core';
import{BrowserModule} from'@angular/platform-browser';
import{AppComponent} from './appcomponent';
import{EmployeeComponent} from './Employeecomponent';



@NgModule({
declarations:[EmployeeComponent,AppComponent],
imports:[ BrowserModule],
bootstrap:[AppComponent]
})

export class AppModule{}



