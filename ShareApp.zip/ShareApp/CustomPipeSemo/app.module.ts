import{NgModule} from '@angular/core';
import{Component} from '@angular/core';
import{EmployeeComponent} from './app.empcomponent';
import {BrowserModule}from '@angular/platform-browser';
import{Customepipe} from './app.custompipe';
@Component({
    selector:'my-app',
    template:`<div>
    <list-emp> </list-emp>
    </div>`
})
export class AppComponent{}

@NgModule({
    declarations:[AppComponent,EmployeeComponent,Customepipe],
    imports:[BrowserModule],
    bootstrap:[AppComponent]
})
export class AppModule{}

