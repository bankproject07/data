import {Component} from '@angular/core'
@Component({
selector:'my-app',
templateUrl:"./display.html"


})
export class BaseClassComponent{
    employees:any[]=[
        {id:1,name:"Anjulata",gender:"male",location:"Pune"},
        {id:2,name:"Uma",gender:"female",location:"Banglore"},
        {id:3,name:"Amit",gender:"male",location:"Pune"},
        {id:4,name:"Rahul",gender:"male",location:"Pune"},
        {id:5,name:"Ukti",gender:"female",location:"Banglore"}
       
       
    ]
    getCountOfAll():number{
        return this.employees.length;
    }
    getCountOfAllMale():number{
        return this.employees.filter(e=>e.gender==="male").length;
    }

    getCountOfAllFemale():number{
        return this.employees.filter(e=>e.gender==="female").length;
    }

}