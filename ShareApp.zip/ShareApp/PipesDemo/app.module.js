"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var core_2 = require("@angular/core");
var core_3 = require("@angular/core");
var CustomPipe = (function () {
    function CustomPipe() {
    }
    CustomPipe.prototype.transform = function (value, args) {
        if (args === "upper") {
            return value.toUpperCase();
        }
        else {
            return value.toLowerCase();
        }
    };
    return CustomPipe;
}());
CustomPipe = __decorate([
    core_3.Pipe({ name: 'changeCase' })
], CustomPipe);
var PipeDemoComponent = (function () {
    function PipeDemoComponent() {
        this.name = "anil";
        this.today = new Date();
    }
    return PipeDemoComponent;
}());
PipeDemoComponent = __decorate([
    core_2.Component({
        selector: 'my-app',
        template: "  \n          <div>\n             <h1> Pipe Demo </h1>\n             <h2> Name - {{name|uppercase}} </h2>\n             <h3> Name - {{name|changeCase:'lowercase'}} </h3>\n             <h2> Date - {{today|date:\"dd, EEEE MMMM yyyy\"|uppercase}} </h2>\n          </div>\n        "
    })
], PipeDemoComponent);
exports.PipeDemoComponent = PipeDemoComponent;
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        declarations: [PipeDemoComponent, CustomPipe],
        imports: [platform_browser_1.BrowserModule],
        bootstrap: [PipeDemoComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map