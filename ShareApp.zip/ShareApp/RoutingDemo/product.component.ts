import{Component} from '@angular/core';

@Component({
    selector:'my-app',
    template:`
    <h4>This is Product Component</h4>
    `
})
export class ProductComponent{}