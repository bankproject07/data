import{Component} from '@angular/core';
import {BrowserModule}from '@angular/platform-browser';

@Component({

    selector:'my-app',
    template:`
    <div>
    <h4>Template Vegetables</h4>
    <ul>
        <li *ngFor="let food of veggies">
            <img src="{{food.image}}"/>
            {{food.name}}
         </li>
    </ul>
    
    </div>
    `
})

export class VegComponent{
  
    veggies:any[]=[
        {name:"beans",image:"./RoutingDemoSecondApp/images/V1.jpg"},
        {name:"carrot",image:"./RoutingDemoSecondApp/images/V2.jpg"},
        {name:"CauliFlower",image:"./RoutingDemoSecondApp/images/V3.jpg"}
    ]

}