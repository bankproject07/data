import{Component} from '@angular/core';

@Component({
    selector:'my-app',
    template:`
    <h4>Page Not Found</h4>
    `
})
export class PageNotFound{}