import{Component} from '@angular/core';
import{BrowserModule} from '@angular/platform-browser';
@Component({
    selector:'my-app',
    template:`
    <div>
    <h4>Template Fruits</h4>
    <ul>
    
        <li *ngFor="let food of fruits">
            <img src="{{food.image}}"/>
        {{food.name}}
        </li>
    </ul>
    
    </div>
    `
    
})
export class FruitsComponent{
fruits:any=[
{name:"Grapes", image:"./RoutingDemoSecondApp/images/G1.jpg"},
{name:"Mango",image:"./RoutingDemoSecondApp/images/M1.jpg"}]
}