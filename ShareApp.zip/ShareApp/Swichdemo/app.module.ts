import {NgModule} from '@angular/core';
import{Component} from'@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';

@Component({
selector:'my-app',
template:`

<h3> Select type of formation</h3><br/>
Enter 1 to List View:<br/>
Enter 2 to Table View:<br/>
 <input type= "text" [ngModel]="value"/>
         <div [ngSwitch]="value">
           <p *ngSwitchCase="1">
                     one
            </p>

             <p *ngSwitchCase="2">
             two

            </p>
          </div>

`

})
export class switchComponent {
    value:number=1;
   
}


@NgModule({
    declarations:[switchComponent ],
    imports:[FormsModule,BrowserModule],
    bootstrap:[switchComponent ]
    
    })
export class AppModule{}