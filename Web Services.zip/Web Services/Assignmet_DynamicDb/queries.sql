create table Product_temp(
id number,
name varchar(15),
price number(6,2)
);

create sequence pro_temp_seq start with 1000 increment by 10; 

insert into Product_temp values(pro_temp_seq.nextval,'Laptop',4567.34);

insert into Product_temp values(pro_temp_seq.nextval,'IPhone',8467.34);
insert into Product_temp values(pro_temp_seq.nextval,'IPod',1200.99);
insert into Product_temp values(pro_temp_seq.nextval,'Data Cable',5000.60);

select* from PRODUCT_TEMP;
select pro_temp_seq.nextVal from dual;