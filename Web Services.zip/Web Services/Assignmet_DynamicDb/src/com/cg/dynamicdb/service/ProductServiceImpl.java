package com.cg.dynamicdb.service;

import java.util.List;

import com.cg.dynamicdb.bean.Product;
import com.cg.dynamicdb.dao.IProductDao;
import com.cg.dynamicdb.dao.ProductDaoImpl;
import com.cg.dynamicdb.exception.ProductException;

public class ProductServiceImpl implements IProductService {

	private IProductDao dao;
	
	public ProductServiceImpl() {
		super();
		dao=new ProductDaoImpl();
	}

	@Override
	public int addProduct(Product product) throws ProductException {
		// TODO Auto-generated method stub
		return dao.addProduct(product);
	}

	@Override
	public Product getProduct(int id) throws ProductException {
		// TODO Auto-generated method stub
		return dao.getProduct(id);
	}

	@Override
	public List<Product> getAllProducts() throws ProductException {
		// TODO Auto-generated method stub
		return dao.getAllProducts();
	}

	@Override
	public void removeProduct(int id) throws ProductException {
		dao.removeProduct(id);		
	}

}
