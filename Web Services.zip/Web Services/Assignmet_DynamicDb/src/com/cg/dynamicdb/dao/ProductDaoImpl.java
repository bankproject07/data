package com.cg.dynamicdb.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.dynamicdb.bean.Product;
import com.cg.dynamicdb.exception.ProductException;
import com.cg.dynamicdb.util.DBUtil;

public class ProductDaoImpl  implements IProductDao{
Statement st;
PreparedStatement ps;
ResultSet rs;
	@Override
	public int addProduct(Product product) throws ProductException {
		
		int productId=-1;
		try(Connection con=DBUtil.getConnection())
		{
			st=con.createStatement();
			rs=st.executeQuery("select pro_temp_seq.nextVal from dual");
			if(rs.next()==false)
			{
				System.out.println("sequence not generated:");
				
			}
			
			ps=con.prepareStatement("insert into Product_temp values(?,?,?)");
			System.out.println(rs.getInt(1));
			ps.setInt(1,rs.getInt(1));			
			ps.setString(2,product.getName());
			ps.setDouble(3,product.getPrice());
			ps.execute();
			productId=product.getId();
			System.out.println(productId);
			
			
		}
		catch(Exception e)
		{
			throw new ProductException("No data added:");
		   }
		return productId;
	}

	@Override
	public Product getProduct(int id) throws ProductException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getAllProducts() throws ProductException {
		List<Product>result=new ArrayList();
		try(Connection con=DBUtil.getConnection())
		{
			st=con.createStatement();
			rs=st.executeQuery("select * from Product_temp");
			while(rs.next())
			{
				Product p1=new Product();
				p1.setId(rs.getInt(1));
				p1.setName(rs.getString(2));
				p1.setPrice(rs.getDouble(3));
				result.add(p1);
			}
			
		}
		catch(Exception e)
		{
			throw new ProductException("No data available:");
		}
		
		
		return result;
	}

	@Override
	public void removeProduct(int id) throws ProductException {
		// TODO Auto-generated method stub
		
	}

}
