package com.cg.dynamicdb.controller;

import java.util.List;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.PathVariable;

import sun.awt.SunHints.Value;

import com.cg.dynamicdb.bean.Product;
import com.cg.dynamicdb.exception.ProductException;
import com.cg.dynamicdb.service.IProductService;
import com.cg.dynamicdb.service.ProductServiceImpl;

@Path("/productdata")
public class ProductController
{

	private IProductService service;

	public ProductController() 
	{
		super();
		  service=new ProductServiceImpl();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	
	public List<Product>getdata()
	{
		List<Product>result=null;
		try {
			result=service.getAllProducts();
			System.out.println(result);
		} 
		catch (ProductException e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	@POST
	@Path("/adddata")
	@Produces(MediaType.APPLICATION_JSON)
	public Product addData(@FormParam("txtpname") String name,@FormParam("txtprice") double price)
	
	{
	Product p1=new Product();
	p1.setName(name);
	p1.setPrice(price);
	try {
		service.addProduct(p1);
		System.out.println(p1);
	} 
	catch (ProductException e) 
	{
		e.printStackTrace();
	}
	return p1;
	}
	
}
