package com.cg.webservice.publisher;

import javax.xml.ws.Endpoint;

import com.cg.webservice.IWSProduct;
import com.cg.webservice.WSProductIml;


public class PublisherClass 
{

	public static void main(String arg[])
	{
		IWSProduct service=new WSProductIml();
		Endpoint.publish("http://localhost:9011/ps?wsdl",service);
		System.out.println("Services are available with port 9011:");
	}
}
