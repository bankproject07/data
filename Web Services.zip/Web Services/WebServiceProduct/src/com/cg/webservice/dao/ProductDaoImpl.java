package com.cg.webservice.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.webservice.bean.Product;
import com.cg.webservice.exception.ProductException;
import com.cg.webservice.util.DBUtil;

public class ProductDaoImpl  implements IProductDao{
	Statement st;
	ResultSet rs;
	PreparedStatement ps;
	@Override
	public List<Product> getAllProduct() throws ProductException 
	{
	
	List<Product>plist=new ArrayList<>();

	try(Connection con=DBUtil.getConnection())
	{
		st=con.createStatement();
		rs=st.executeQuery("select * from Product");
		while(rs.next())
		{
			Product np=new Product();
			np.setName(rs.getString("name"));
			np.setPrice(rs.getInt("price"));
			plist.add(np);
		}
		
		
	}
	
		catch(Exception e)
	{
		
		throw new ProductException("No data Found:");	
		
	}
	
	return plist;
	}

	@Override
	public int getPrice(String name) throws ProductException {
		int price=-1;
		try(Connection con=DBUtil.getConnection())
		{
			ps=con.prepareStatement("select price from Product where name=?");
			ps.setString(1,name);
			rs=ps.executeQuery();
			while(rs.next())
			{
				Product np=new Product();
				np.setName(rs.getString(1));
				np.setPrice(rs.getInt("price"));
				price=np.getPrice();
			}
			
		}
		
		catch(Exception e)
	{ throw new ProductException(e.getMessage());	}
	
		return price;
	}

	@Override
	public int getPriceById(int id) throws ProductException {
		int price=-1;
		try(Connection con=DBUtil.getConnection())
		{
			ps=con.prepareStatement("select price from Product where id=?");
			ps.setInt(1,id);
			rs=ps.executeQuery();
			while(rs.next())
			{
				Product np=new Product();
				np.setName(rs.getString(1));
				np.setPrice(rs.getInt("price"));
				price=np.getPrice();
			}
			
		}
		
		catch(Exception e)
	{ throw new ProductException(e.getMessage());	}
	
		return price;
	}

	
}
