package com.cg.webservice.dao;

import java.util.List;

import com.cg.webservice.bean.Product;
import com.cg.webservice.exception.ProductException;

public interface IProductDao {
	
	public List<Product>getAllProduct()throws ProductException;
	public int getPrice(String name)throws ProductException;
	public int getPriceById(int id)throws ProductException;

}
