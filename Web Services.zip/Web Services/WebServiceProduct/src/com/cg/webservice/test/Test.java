package com.cg.webservice.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.webservice.bean.Product;
import com.cg.webservice.exception.ProductException;
import com.cg.webservice.service.IProductService;
import com.cg.webservice.service.ProductServiceImpl;

public class Test {
	IProductService service=new ProductServiceImpl();
	public void menu()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Select Choice: \n 1  for List \n 2 for Price By Name: \n 3: for get price based on id");
		int c=sc.nextInt();
		switch(c)
		{
		case 1: list();break;
		case 2: getprice();break;
		case 3: getpriceId();
		case 4:System.exit(0);
		default:System.out.println("select valid:");
			
		}
		

	}


	public void list()
	{
		System.out.println("List:");
		List<Product>list=new ArrayList<>();
		try{
		list=service.getAllProduct();
		System.out.println(list);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}

	}
	
	public void getprice()
	{
		Scanner sc=new Scanner(System.in);
		try {
			System.out.print("Enter name");
			String name=sc.next();
			int p=service.getPrice(name);
			System.out.println("price="+p);
		}
		catch (ProductException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public void getpriceId()
	{
		Scanner sc=new Scanner(System.in);
		try {
			System.out.print("Enter Id");
			int id=sc.nextInt();
			int p=service.getPriceById(id);
			System.out.println("price="+p);
		}
		catch (ProductException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	
	
	
public static void main(String arg[])
{
	Test t1=new Test();
	while(true)
	{
		t1.menu();
	}
}
}
	
/*System.out.println("List:");
List<Product>list=new ArrayList<>();
try{
list=service.getAllProduct();
System.out.println(list);
}
catch(Exception e)
{
	System.out.println(e.getMessage());
		

try {
	int p=service.getPrice("VIVO");
	System.out.println("price="+p);
}
catch (ProductException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

*/		

