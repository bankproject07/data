package com.cg.webservice;

import java.util.List;

import javax.jws.WebService;

import com.cg.webservice.bean.Product;
import com.cg.webservice.exception.ProductException;


@WebService(endpointInterface="com.cg.webservice.IWSProduct")
public class WSProductIml implements IWSProduct{
private com.cg.webservice.service.IProductService service;

	public WSProductIml()
	{
	super();
	service=new com.cg.webservice.service.ProductServiceImpl();
	
}

	@Override
	public List<Product> getAllProduct() throws ProductException {
		// TODO Auto-generated method stub
		return service.getAllProduct();
	}

	@Override
	public int getPrice(String name) throws ProductException {
		// TODO Auto-generated method stub
		return service.getPrice(name);
	}

	@Override
	public int getPriceById(int id) throws ProductException {
		// TODO Auto-generated method stub
		return service.getPriceById(id);
	}

}
