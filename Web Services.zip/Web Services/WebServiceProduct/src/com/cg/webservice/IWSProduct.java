package com.cg.webservice;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import com.cg.webservice.bean.Product;
import com.cg.webservice.exception.ProductException;

@WebService
@SOAPBinding(style=Style.DOCUMENT)
public interface IWSProduct
{
	@WebMethod
	public List<Product>getAllProduct()throws ProductException;
	@WebMethod
	public int getPrice(String name)throws ProductException;
	@WebMethod
	public int getPriceById(int id)throws ProductException;

}

