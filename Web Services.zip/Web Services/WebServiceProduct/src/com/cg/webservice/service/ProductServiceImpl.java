package com.cg.webservice.service;

import java.util.List;

import com.cg.webservice.bean.Product;
import com.cg.webservice.dao.IProductDao;
import com.cg.webservice.dao.ProductDaoImpl;
import com.cg.webservice.exception.ProductException;

public class ProductServiceImpl implements IProductService {
public IProductDao dao;

	public ProductServiceImpl()
	{
	super();
	dao=new ProductDaoImpl();
}

	@Override
	public List<Product> getAllProduct() throws ProductException {
		return dao.getAllProduct();
	}

	@Override
	public int getPrice(String name) throws ProductException {
		return dao.getPrice(name);
	}

	@Override
	public int getPriceById(int id) throws ProductException {
		// TODO Auto-generated method stub
		return dao.getPriceById(id);
	}

}
