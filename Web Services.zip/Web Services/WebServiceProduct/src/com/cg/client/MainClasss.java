package com.cg.client;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import com.cg.webservice.IWSProduct;
import com.cg.webservice.WSProductIml;
import com.cg.webservice.bean.Product;
import com.cg.webservice.exception.ProductException;

public class MainClasss {
	
	public IWSProduct pser=new WSProductIml();
	
	public void list()
	{
		System.out.println("List:");
		List<Product>list=new ArrayList<>();
		try
		{
		list=pser.getAllProduct();
		System.out.println(list);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	public void getprice()
	{
		Scanner sc=new Scanner(System.in);
		try {
			System.out.print("Enter name");
			String name=sc.next();
			int p=pser.getPrice(name);
			System.out.println("price="+p);
		}
		catch (ProductException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
		public void getpriceId()
		{
			Scanner sc=new Scanner(System.in);
			try {
				System.out.print("Enter Id");
				int id=sc.nextInt();
				int p=pser.getPriceById(id);
				System.out.println("price="+p);
			}
			catch (ProductException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


	}
		public void menu()
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Select Choice: \n 1  for List \n 2 for Price By Name: \n 3: for get price based on id");
			int c=sc.nextInt();
			switch(c)
			{
			case 1: list();break;
			case 2: getprice();break;
			case 3: getpriceId();
			case 4:System.exit(0);
			default:System.out.println("select valid:");
				
			}
			

		}

	
	
	
	
	
public static void main(String arg[]) throws ProductException
{
	try {
		
	URL url=new URL("http://localhost:9011/ps?wsdl");
	QName qname=new QName("http://webservice.cg.com/","WSProductImlService");
	Service service=Service.create(url,qname);	
	}
	
	catch (Exception e) 
	{
		e.printStackTrace();
	}
	
	MainClasss m=new MainClasss();
	while(true){
	m.menu();
	
	}
	
	
	
	
	
}
}
