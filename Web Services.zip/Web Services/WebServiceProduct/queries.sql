select * from Product;
update PRODUCT set price=2000 where id=4950;


select price from Product where name="java";

insert into Product values(pro_seq.nextVal,'Phone','VIVO',15000,2);