package com.capgemini.client;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import com.capgemini.entities.Product;
import com.capgemini.ws.IProductService;


public class TestWS {

	public static void main(String[] args) {
		
		
		//Create Url
		URL url=null;
		try {
			url = new URL("http://localhost:9995/products?wsdl");
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Create Qualification Name
		QName qname=new QName("http://ws.capgemini.com/","ProductServiceImplService");
		
		//Create service
		Service service=Service.create(url, qname);
				
		//Create port
		IProductService pServices=service.getPort(IProductService.class);
		
		//Procure Service
		Product product=pServices.getProduct(11);
		System.out.println(product);
		
		/*List<Product> pList = pServices.getAllProducts();
		
		for(Product prod : pList)
		{
			System.out.println(prod);
		}*/
	}

}
