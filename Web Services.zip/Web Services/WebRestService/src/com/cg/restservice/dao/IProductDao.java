package com.cg.restservice.dao;

import java.util.List;

import com.cg.restservice.bean.Product;

public interface IProductDao {
	public List<Product>getAllProducts();
	public Product getProduct(int id);
	public void addProduct(Product product);
	public Product deleteProduct(int id);


}
