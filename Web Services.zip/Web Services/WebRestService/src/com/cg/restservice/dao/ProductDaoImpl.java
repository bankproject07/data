
package com.cg.restservice.dao;

import java.util.List;

import com.cg.restservice.bean.Product;
import com.cg.restservice.staticdb.ProductDb;

public class ProductDaoImpl implements IProductDao {

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return ProductDb.getPlist();
	}

	@Override
	public Product getProduct(int id) {
		// TODO Auto-generated method stub
		return ProductDb.getPlist().get(id);
	}

	@Override
	public void addProduct(Product product) {
		// TODO Auto-generated method stub
		 ProductDb.getPlist().add(product);
	}

	@Override
	public Product deleteProduct(int id) {
		
		return ProductDb.getPlist().remove(id);
	}

}
