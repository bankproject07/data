package com.cg.restservice.bean;

public class Product {
private String proName;
private int proId;
private double proPrice;
public Product() 
{
	super();
}
public Product(String proName, int proId, double proPrice) {
	super();
	this.proName = proName;
	this.proId = proId;
	this.proPrice = proPrice;
}
public String getProName() {
	return proName;
}
public void setProName(String proName) {
	this.proName = proName;
}
public int getProId() {
	return proId;
}
public void setProId(int proId) {
	this.proId = proId;
}
public double getProPrice() {
	return proPrice;
}
public void setProPrice(double proPrice) {
	this.proPrice = proPrice;
}
@Override
public String toString() {
	return "Product [proName=" + proName + ", proId=" + proId + ", proPrice="
			+ proPrice + "]";
}




}
