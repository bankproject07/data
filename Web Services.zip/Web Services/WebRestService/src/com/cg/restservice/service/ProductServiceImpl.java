package com.cg.restservice.service;

import java.util.List;

import com.cg.restservice.bean.Product;
import com.cg.restservice.dao.IProductDao;
import com.cg.restservice.dao.ProductDaoImpl;

public class ProductServiceImpl  implements IProductService{
private 	IProductDao dao;

	public ProductServiceImpl() {
	super();
dao=new ProductDaoImpl();
}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return dao.getAllProducts();
	}

	@Override
	public Product getProduct(int id) {
		// TODO Auto-generated method stub
		return dao.getProduct(id);
	}

	@Override
	public void addProduct(Product product) {
		// TODO Auto-generated method stub
		 dao.addProduct(product);
	}

	@Override
	public Product deleteProduct(int id) {
		return dao.deleteProduct(id);
	}

}
