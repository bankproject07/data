package com.cg.restservice.staticdb;

import java.util.ArrayList;
import java.util.List;

import com.cg.restservice.bean.Product;

public class ProductDb {
private static List<Product>plist=new ArrayList();
static{
	plist.add(new Product("Laptop",101,45678.34));
	plist.add(new Product("IPad",102,65678.84));
	plist.add(new Product("IPhone",103,84678.34));
	plist.add(new Product("IPod",104,1200.99));
	plist.add(new Product("Disk",105,5000.00));
	plist.add(new Product("Fit Bit Wrist Band",106,2000.50));
	plist.add(new Product("Data Cable",107,5000.60));
	plist.add(new Product("Arm sleeves",108,500.12));
	plist.add(new Product("Samsung Tab",109,4000.26));
	plist.add(new Product("DVD",110,345323.00));
	plist.add(new Product("Adapter",111,75678.00));
	
}
public static List<Product> getPlist() {
	return plist;
}
public static void setPlist(List<Product> plist) {
	ProductDb.plist = plist;
}





}
