package com.cg.restservice.controller;

import java.util.List;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.cg.restservice.bean.Product;
import com.cg.restservice.service.IProductService;
import com.cg.restservice.service.ProductServiceImpl;

@Path("/productlists")
public class ProductController 
{
	private IProductService service;

	public ProductController()
	{
		service = new ProductServiceImpl() ;
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product>getProducts()
	{
		List<Product>result=service.getAllProducts();

		System.out.println(result);
		return result;
	}
	
	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public void getProductById(@PathParam("id") int id)
	{
		service.getProduct(id);
		System.out.println(service.getProduct(id));
	}

	
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public Product addProduct(@FormParam("txyf2") int id,@FormParam("txyf1") String name,@FormParam("txyf3") double price)
	{
		Product p1 = new Product();
		p1.setProId(id);
		p1.setProName(name);
		p1.setProPrice(price);
		service.addProduct(p1);
		System.out.println("product Added with:"+p1.getProId());

		return p1;
	}
	
	
	
	@POST
	@Path("/remove")
	@Produces(MediaType.APPLICATION_JSON)

		public Product deleteProductById(@FormParam("txt1") int id)
		{
		
			Product p2=service.deleteProduct(id);
		
			
			if(p2!=null)
			{
			return p2;
			}
			else
			{
				return new Product();
			}
		}


}
