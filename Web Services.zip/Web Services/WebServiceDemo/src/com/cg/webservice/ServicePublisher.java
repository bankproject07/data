package com.cg.webservice;

import javax.xml.ws.Endpoint;



public class ServicePublisher
{
	public static void main(String arg[])
	{
		Endpoint.publish("http://localhost:9010/cs?wsdl",new Calculator());
		System.out.println("Product Services are published:");
	}

}


