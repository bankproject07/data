package com.cg.webservice;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;


public class MainUser 
{

	public static void main(String arg[]) throws Exception
	{
		URL url=new URL("http://localhost:9010/cs?wsdl");
		QName qname=new QName("http://webservice.cg.com/","CalculatorService");
		Service service=Service.create(url,qname);
		CalculatorServer endPoint=service.getPort(CalculatorServer.class);
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first number:");
		int n1=sc.nextInt();
		
		System.out.println("Enter second number:");
		int n2=sc.nextInt();
		System.out.println("Addition:"+endPoint.addition(n1, n2));
		System.out.println("Subtraction:"+endPoint.subtraction(n1, n2));
		System.out.println("Multiplication:"+endPoint.modulus(n1, n2));
		System.out.println("Division:"+endPoint.division(n1, n2));
	}
}


