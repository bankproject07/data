package com.cg.spring_angular.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring_angular.bean.Product;
import com.cg.spring_angular.dao.IProductDao;
import com.cg.spring_angular.dao.ProductDaoImpl;
import com.cg.spring_angular.exception.ProductException;
@Service("service")
@Transactional
public class ProductServiceImpl implements IProductService {
@Autowired
	private IProductDao dao;
	
	/*public ProductServiceImpl() {
		super();
		dao=new ProductDaoImpl();
	}*/

	@Override
	public int addProduct(Product product) throws ProductException {
		// TODO Auto-generated method stub
		return dao.addProduct(product);
	}

	@Override
	public Product getProduct(int id) throws ProductException {
		// TODO Auto-generated method stub
		return dao.getProduct(id);
	}

	@Override
	public List<Product> getAllProducts() throws ProductException {
		// TODO Auto-generated method stub
		return dao.getAllProducts();
	}

	@Override
	public void removeProduct(int id) throws ProductException {
		dao.removeProduct(id);		
	}

}
