package com.cg.spring_angular.dao;

import java.util.List;

import com.cg.spring_angular.bean.Product;
import com.cg.spring_angular.exception.ProductException;

public interface IProductDao {
	public int addProduct(Product product)throws ProductException;
	public Product getProduct(int id)throws ProductException;
	public List<Product>getAllProducts() throws ProductException;
	public void removeProduct(int id)throws ProductException;

}
