package com.cg.spring_angular.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.spring_angular.bean.Product;
import com.cg.spring_angular.exception.ProductException;
import com.cg.spring_angular.util.DBUtil;
@Repository("dao")
public class ProductDaoImpl  implements IProductDao{
	@PersistenceContext
	@Autowired
	public EntityManager manager;
Statement st;
PreparedStatement ps;
ResultSet rs;
Product p1=null;
	@Override
	public int addProduct(Product product) throws ProductException {
		int productId=-1;
		
		try{
			manager.getTransaction().begin();
			manager.persist(p1);
			productId=p1.getId();
		}
		catch(Exception e)
		{
			throw new ProductException("data not aded:");
		}
		finally
		{
			manager.getTransaction().commit();
		}
		
		return productId;
		
			}

	@Override
	public Product getProduct(int id) throws ProductException {
		try{
		
			p1=manager.find(Product.class,id);
	
		
		}
		catch(Exception e)
		{
			throw new ProductException("data not available:");
		}
		finally
		{
			manager.getTransaction().commit();
		}
	
		
		
			return p1;
	}

	@Override
	public List<Product> getAllProducts() throws ProductException {
		return null;
		}

	@Override
	public void removeProduct(int id) throws ProductException {
		try{
			manager.getTransaction().begin();
			manager.remove(p1);
			System.out.println("Product removved:");
		
	
		
		}
		catch(Exception e)
		{
			throw new ProductException("data not available:");
		}
		finally
		{
			manager.getTransaction().commit();
		}
	

	
		
	}

}
