create table Demo_User(
id number(6) primary key,
fname varchar(10),
lname varchar(10), 
uid varchar(10),
password varchar(10),
cpassword varchar(10),
phone varchar(10),
email varchar(20),
profile varchar(10),
location varchar(10)
);
