package com.cg.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.AlcDaoImpl;
import com.cg.dao.IAlcDao;
import com.cg.entities.AlcUser;
import com.cg.exception.AlcException;
@Service("service")
@Transactional
public class AlcServiceImpl implements IAlcService {
	@Autowired
	public IAlcDao dao;
	@Override
	public int adduser(AlcUser user) throws AlcException {
		// TODO Auto-generated method stub
		return dao.adduser(user);
	}

	@Override
	public List<AlcUser> getAllUser() throws AlcException {
		// TODO Auto-generated method stub
		return dao.getAllUser();
	}

}
