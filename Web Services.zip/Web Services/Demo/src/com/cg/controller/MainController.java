package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javassist.bytecode.stackmap.BasicBlock.Catch;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entities.AlcUser;
import com.cg.exception.AlcException;
import com.cg.services.IAlcService;
@Controller
public class MainController 
{
	@Autowired
	public IAlcService service;
	

	public MainController() {	}
	
	

	public MainController(IAlcService service) {
		super();
		this.service = service;
	}



	public IAlcService getService() {
		return service;
	}

	public void setService(IAlcService service) {
		this.service = service;
	}
/*@RequestMapping("mainHomePage")
public String getMainPage()
{
	return "mainHomePage";
}	*/

	
	

@RequestMapping("newUser")
public String getNewUserPage(Model model)
{
	List<String>profiles=new ArrayList<>();
	profiles.add("ACS (Alternate Connectivity Solution)");
	profiles.add("PA/CSE (Connectivity Solution Expert)");
	profiles.add("Sales");
	profiles.add("CP");
	profiles.add("Data admin");
	profiles.add("Supervisor");
	profiles.add("Billing Group");
	profiles.add("Buyer");
	profiles.add("TSE");
	
	List<String>location=new ArrayList<>();
	location.add("---");
	location.add("India");
	location.add("Pakistan");
	location.add("SriLanka");
	location.add("China");
	location.add("USA");
	
	model.addAttribute("user",new AlcUser());
	model.addAttribute("profile", profiles);
	model.addAttribute("location",location);
	
	return "NewUserPage";
}	




}
