package com.cg.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name="Demo_User")
public class AlcUser {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="demo_seq_hseq")
	@SequenceGenerator(name="demo_seq_hseq",sequenceName="demo_seq",initialValue=1000)
	
	private int id;
	private String fname;
	private String lname;
	private String uid;
	private String password;
	private String cpassword;
	private String phone;
	private String email;
	private String location;
	private String profile;
	public AlcUser() {
		super();
	}
	public AlcUser(int id, String fname, String lname, String uid,
			String password, String cpassword, String phone, String email,
			String location, String profile) {
		super();
		this.id = id;
		this.fname = fname;
		this.lname = lname;
		this.uid = uid;
		this.password = password;
		this.cpassword = cpassword;
		this.phone = phone;
		this.email = email;
		this.location = location;
		this.profile = profile;
	}
	public AlcUser(String fname, String lname, String uid, String password,
			String cpassword, String phone, String email, String location,
			String profile) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.uid = uid;
		this.password = password;
		this.cpassword = cpassword;
		this.phone = phone;
		this.email = email;
		this.location = location;
		this.profile = profile;
	}
	@Override
	public String toString() {
		return "AlcUser [id=" + id + ", fname=" + fname + ", lname=" + lname
				+ ", uid=" + uid + ", password=" + password + ", cpassword="
				+ cpassword + ", phone=" + phone + ", email=" + email
				+ ", location=" + location + ", profile=" + profile + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCpassword() {
		return cpassword;
	}
	public void setCpassword(String cpassword) {
		this.cpassword = cpassword;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getProfile() {
		return profile;
	}
	public void setProfile(String profile) {
		this.profile = profile;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AlcUser other = (AlcUser) obj;
		if (id != other.id)
			return false;
		return true;
	}
	
	
	

}
