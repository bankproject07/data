package com.cg.dao;

import java.util.List;

import com.cg.entities.AlcUser;
import com.cg.exception.AlcException;

public interface IAlcDao {
	public int adduser(AlcUser user) throws AlcException;
	public List<AlcUser> getAllUser()throws AlcException;

}
