package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.entities.AlcUser;
import com.cg.exception.AlcException;
@Repository("dao")
public class AlcDaoImpl implements IAlcDao {
	@PersistenceContext
	public EntityManager em;

	@Override
	public int adduser(AlcUser user) throws AlcException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<AlcUser> getAllUser() throws AlcException {
		// TODO Auto-generated method stub
		return null;
	}

}
