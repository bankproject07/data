package com.capgemini.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.entities.Product;
import com.capgemini.service.IProductService;

@Controller
public class ProductController
{
		@Autowired
	 IProductService productService;

		public ProductController()
		{
		}

		public ProductController(IProductService productService) 
		{
			super();
			this.productService = productService;
		}

		public IProductService getProductService() 
		{
			return productService;
		}

		public void setProductService(IProductService productService)
		{
			this.productService = productService;
		}
		
		@RequestMapping("home")
		public String getHomepage()
		{
			return "HomePage";
		}
		
		
		
		//Initialization of add product
		@RequestMapping("addproduct")
		  public String getAddProduct(Model model)

		 {
				List<String> catgoreis=new ArrayList<>(); 
				catgoreis.add("Books");
				catgoreis.add("Sarees");
				catgoreis.add("Furnitures");
				catgoreis.add("Electronics");
				
				//Add the form backing bean to be
				model.addAttribute("product",new Product());
				
				//Add categories to build drop down list in addproduct
				model.addAttribute("categories",catgoreis);
				return "AddProductPage";
		 }
		
		@RequestMapping(value="processaddproductform")
		public ModelAndView processAddaProductForm(
				@ModelAttribute("product") @Valid Product product,
				BindingResult result,
				Model model)
		{
			if(result.hasErrors()==true)
			{
				List<String> catgoreis=new ArrayList<>(); 
				catgoreis.add("Books");
				catgoreis.add("Sarees");
				catgoreis.add("Furnitures");
				catgoreis.add("Electronics");
				
				//Add the form backing bean to be
				model.addAttribute("product",product);
				
				//Add categories to build drop down list in addproduct
				model.addAttribute("categories",catgoreis);
				return new ModelAndView("AddProductPage");
			}
			
			int productId=-1;
		
			try
			{
				productId=productService.addProduct(product);
				model.addAttribute("message","Product Added Successfully with product id="+product.getId());
				return new ModelAndView("SuccessPage");
			}
			catch(Exception e)
			{
				model.addAttribute("errmsg","Product not Found:");
				return new ModelAndView("ErrorPage");
			}
			
		
		}
		
		
		/*@RequestMapping("getproduct")
	public String getProductPage()
	{
		return "GetProductPage";
	}
	
	@RequestMapping("processgetproductform")
	public ModelAndView processGetProductForm(@RequestParam("productId") int pid)
	{
		Product product=null;
		try 
		{
			product =productService.getProduct(pid);
			return new ModelAndView("GetProductPage","product",product);
		} 
		catch (Exception e) 
		{
			return new ModelAndView("ErrorPage","errMsg",
					"Could not retrieve the product. Reason : "+e.getMessage());

		}
	}
	
		 * 
		 */
		@RequestMapping("getproduct")
		public String getProduct()
		{
			return "GetProductPage";
		}
	@RequestMapping("processgetproductform")
	public ModelAndView processgetproductform(@RequestParam("productId") int id)
	{
		Product product=null;
		try
		{
			product=productService.getProduct(id);
			return new ModelAndView("GetProductPage","product",product);
		}
		catch(Exception e)
		{
			return new ModelAndView("ErrorPage","message",
					"Could not retrieve the product. Reason : "+e.getMessage());
		}
		
	}
	@RequestMapping("viewallproduct")
	public String getAllProducts(Model model)
	{
		List<Product> products=null;
		try
		{
			products=productService.getAllProduct();
			model.addAttribute("products",products);
			return "ViewAllProductPage";
			
		}
		catch(Exception e)
		{
			return "ErrorPage";
		}
	}
	
	@RequestMapping("getupdatepage")
	public String getUpdatePage(@RequestParam("id") int id,Model model)
	{
		List<String> catgoreis=new ArrayList<>(); 
		catgoreis.add("Books");
		catgoreis.add("Sarees");
		catgoreis.add("Furnitures");
		catgoreis.add("Electronics");
		Product product=null;
		try
		{
			product=productService.getProduct(id);
		}
		catch(Exception e)
		{
			model.addAttribute("errmsg","Couldn't found details:Reasons:"+e.getMessage());
			return "ErrorPage";
		}
		//Add the form backing bean to be
		model.addAttribute("product",product);
		
		//Add categories to build drop down list in addproduct
		model.addAttribute("categories",catgoreis);
		return "UpdatePage";
	}
	
	@RequestMapping(value="processupdatepageform",method=RequestMethod.POST)
	public String getUpdateForm(Model model)
	{
		Product product =null;

		List<String> catgoreis=new ArrayList<>(); 
		catgoreis.add("Books");
		catgoreis.add("Sarees");
		catgoreis.add("Furnitures");
		catgoreis.add("Electronics");
		
		//Add the form backing bean to be
		model.addAttribute("product",new Product());
		
		//Add categories to build drop down list in addproduct
		model.addAttribute("categories",catgoreis);
		
	
	try
	{
		productService.updateProduct(product);
		return "UpdatePage";
	}
	catch(Exception e)
	{
		model.addAttribute("errmsg","Up[date Not found");
		return "ErrorPage";
	}

}
}

