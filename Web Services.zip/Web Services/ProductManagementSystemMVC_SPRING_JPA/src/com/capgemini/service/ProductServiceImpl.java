package com.capgemini.service;

import java.util.List;



import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.IProductDao;
import com.capgemini.dao.ProductDaoImpl;
import com.capgemini.entities.Product;
import com.capgemini.exception.ProductException;

@Transactional
@Service("service")
public class ProductServiceImpl implements IProductService
{
	@Autowired
	IProductDao productDao;

	public ProductServiceImpl()
	{
		
	}

	public ProductServiceImpl(IProductDao productDao)
	{
		super();
		this.productDao = productDao;
	}
	

	public IProductDao getProductDao() {
		return productDao;
	}

	public void setProductDao(IProductDao productDao) {
		this.productDao = productDao;
	}

	@Override
	public int addProduct(Product product) throws ProductException {
		// TODO Auto-generated method stub
		return productDao.addProduct(product);
	}

	@Override
	public void updateProduct(Product product) throws ProductException {
		productDao.updateProduct(product);

	}

	@Override
	public void removeProduct(int id) throws ProductException {
		
		productDao.removeProduct(id);
	}

	@Override
	public Product getProduct(int pid) throws ProductException {
		// TODO Auto-generated method stub
		return productDao.getProduct(pid);
	}

	@Override
	public List<Product> getAllProduct() throws ProductException {
		// TODO Auto-generated method stub
		return productDao.getAllProduct();
	}

	@Override
	public Product getProduct(String name) throws ProductException {
		// TODO Auto-generated method stub
		return productDao.getProduct(name);
	}

	@Override
	public List<Product> getProductInRange(float a,float b) throws ProductException {
		// TODO Auto-generated method stub
		return productDao.getProductInRange(a,b);
	}

}
