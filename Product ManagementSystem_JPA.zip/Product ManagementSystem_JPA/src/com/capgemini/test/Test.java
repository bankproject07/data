package com.capgemini.test;

import com.capgemini.entities.Product;
import com.capgemini.service.IProductService;
import com.capgemini.service.ProductServiceImpl;

public class Test 
{
public static void main(String arg[])
{/*
	IProductService service=new ProductServiceImpl();
	System.out.println("INSERT");
	Product product=new Product("xyz",10,2000);
	int id=product.getId();

	System.out.println("product Is Created With id:="+id);
	
	//Get Details of product
	System.out.println("SELECT");
	
	Product p1=service.getProduct(id);
	System.out.println("Product Details:"+p1);
	
	//Update 
	System.out.println("UPDATE");
	Product p2=new Product(id,"LAPTOP",2,30000);
	service.updateProduct(p2);
	System.out.println("Update value:"+p2);
	
	service.removeProduct(id);
	System.out.println("Removed");
*/	
}
}
