package com.capgemini.dao;

import java.util.List;

import javax.persistence.EntityManager;




import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.capgemini.entities.Product;
import com.capgemini.exception.ProductException;
import com.capgemini.util.DBUtil;

public class ProductDaoImpl implements IProductDao
{
private EntityManager entityManager;

	public ProductDaoImpl() 
	{
	super();
	entityManager=DBUtil.getEntityManager();
}

	@Override
	public int addProduct(Product product) throws ProductException 
	{
		int productId=0;
		try
		{
			entityManager.getTransaction().begin();
			entityManager.persist(product);
			productId=product.getId();
			entityManager.getTransaction().commit();
			
		}

	catch(Exception e)
		{ 
		entityManager.getTransaction().rollback();
		throw new ProductException(e.getMessage());
		}
	
		return productId;
	}

	@Override
	public void updateProduct(Product product) throws ProductException 
	{
		try
		{
			entityManager.getTransaction().begin();
		entityManager.merge(product);
		entityManager.flush();
		
		entityManager.getTransaction().commit();
			
		}

	catch(Exception e)
		{ 
		entityManager.getTransaction().rollback();
		throw new ProductException(e.getMessage());
		}
	
	}

	@Override
	public void removeProduct(int id) throws ProductException
	{try
		{
			entityManager.getTransaction().begin();
		Product product=entityManager.find(Product.class,id);
		entityManager.remove(product);
	
		entityManager.getTransaction().commit();
			
		}

	catch(Exception e)
		{ 
		entityManager.getTransaction().rollback();
		throw new ProductException(e.getMessage());
		}
		
	}

	@Override
	public Product getProduct(int pid) throws ProductException {
		Product product=null;
		try
		{
		entityManager.getTransaction().begin();
		product=entityManager.find(Product.class,pid);
	
		entityManager.getTransaction().commit();
			
		}

		catch(Exception e)
		{ 
		entityManager.getTransaction().rollback();
		throw new ProductException(e.getMessage());
		}
		if(product==null)
		{
			throw new ProductException("No Product Found:"+pid);
		}
		return product;
	}

	@Override
	public List<Product> getAllProduct() throws ProductException 
	{ List<Product>products=null;
		try
	{
			
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		TypedQuery<Product>query=entityManager.createNamedQuery("getAllProducts",Product.class);
		products=query.getResultList();
		transaction.commit();
	}

	catch(Exception e)
	{
		throw new ProductException(""+e.getMessage());
	}
		if(products==null||products.isEmpty())
		{
			throw new ProductException("No Product to display:::");
		}
		return products;
	}

	@Override
	public Product getProduct(String name) throws ProductException {
		Product product=null;
		try
		{
	EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		
		
	String str="select product from Product product where product.name=:pname";
	TypedQuery<Product>query=entityManager.createQuery(str,Product.class);	
	query.setParameter("pname","Snacks");
 product=query.getSingleResult();
		
		}

		
		
		catch(Exception e)
		{ 
		
		}
		if(product==null)
		{
			throw new ProductException("No Product to display:::");
		}
		
		return product;
	
	}

	@Override
	public List<Product> getProductInRange(float a,float b) throws ProductException 
	{
		String str="Select p from Product p where p.price between:a and :b";
		TypedQuery<Product>query=entityManager.createQuery(str,Product.class);
		query.setParameter("a",a);
		query.setParameter("b",b);
		List<Product>plist=query.getResultList();
		return plist;
	
	}

}
