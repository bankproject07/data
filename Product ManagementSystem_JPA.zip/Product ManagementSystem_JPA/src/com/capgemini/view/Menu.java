package com.capgemini.view;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.entities.Product;
import com.capgemini.exception.ProductException;
import com.capgemini.service.IProductService;
import com.capgemini.service.ProductServiceImpl;

public class Menu
{ IProductService service=new ProductServiceImpl();
char reply;
	public void menu()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Your Choice");
		System.out.println("1:= Add Product");
		System.out.println("2:= Get Product");
		System.out.println("3:= update Product");
		System.out.println("4:= Remove Product");
		System.out.println("5:= View All  Product");	
		System.out.println("6:= Get Product Name");
		System.out.println("7:= Get Product in Range");
		System.out.println("9:= Exit");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
				System.out.println("Enter Product Name:");
				String name=sc.next();
				System.out.println("Enter Product Quantity:");
				int qty=sc.nextInt();
				System.out.println("Enter Product price:");
				float price=sc.nextFloat();
				Product p1=new Product(name,qty,price);
		
			
	
			try
			{
				int id=service.addProduct(p1);
				System.out.println("Product Inserted Sucessfully id:"+p1.getId());
			}
			catch(ProductException e)
			{
				System.out.println("Product is Not Added:"+e.getMessage());
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
			break;
		case 2:
			System.out.println("Enter the product Id To retrive Product Info:");
			System.out.println("Product Id:");
			int productid=sc.nextInt();
			try
			{
				Product p2=service.getProduct(productid);
				System.out.println("ID:"+p2.getId());
				System.out.println("NAME:"+p2.getName());
				System.out.println("Quantity:"+p2.getQuantity());
				System.out.println("Price:"+p2.getPrice());
				
				
			}
			catch(ProductException e)
			{
				System.out.println("Product NOt Found:"+e.getMessage());
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
			break;
			
		case 3:
			System.out.println("Enter Product id to update:");
			int uid=sc.nextInt();
			Product p3=null;

			try
			{
				 p3=service.getProduct(uid);
				System.out.println("Old Product Name:"+p3.getName());
				reply=sc.next().charAt(0);
				if(reply=='y')
				{
					System.out.println("Enter New Name:");
					String newName=sc.next();
					p3.setName(newName);
					
				}
				System.out.println("Old Product Quantity:"+p3.getQuantity());
				reply=sc.next().charAt(0);
				if(reply=='y')
				{
					System.out.println("Enter New Quantity:");
					int quantity=sc.nextInt();
					p3.setQuantity(quantity);
					
				}
				System.out.println("Old Product Price:"+p3.getPrice());
				reply=sc.next().charAt(0);
				if(reply=='y')
				{
					System.out.println("Enter New Price:");
					float nprice=sc.nextFloat();
					p3.setPrice(nprice);
					
				}
				
			}
			catch(ProductException e)
			{
				System.out.println("Product is Not Found:"+e.getMessage());
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
			try
			{
				if(p3!=null)
				{
					service.updateProduct(p3);
				}
			}
			catch(ProductException e)
			{
				System.out.println("Could't update  product"+e.getMessage());
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
			break;
			
		case 4:
			System.out.println("Enter Product id to remove:");
			int rid=sc.nextInt();
			try
			{
				service.removeProduct(rid);
				System.out.println("Removed SuccessFully");
			}
			catch(ProductException e)
			{
				System.out.println("Could't Remove  product"+e.getMessage());
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
			break;
			
		case 5:
			System.out.println("ALL PRODUCTS");
			try
			{
				List<Product>products=service.getAllProduct();
				Iterator<Product>it=products.iterator();
				System.out.printf("%s %s %s %s \n","ID","NAME","QUANTITY","PRICE");
				while(it.hasNext())
				{
					Product product=it.next();
					//System.out.print(product.getId()+" ");
					//System.out.print(product.getName()+" ");
					//System.out.print(product.getQuantity()+" ");
				//	System.out.print(product.getPrice()+\n);
					
					
					
					System.out.printf("%d %s %d %f \n",product.getId(),product.getName(),product.getQuantity(),product.getPrice());
					
				}
			}
			catch(ProductException e)
			{
				System.out.println("Could't Remove  product"+e.getMessage());
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
		
			break;
		case 6:
			System.out.println("Enter the product Name To retrive Product Info:");
			System.out.println("Product Name:");
			String pname=sc.next();
			try
			{
				Product p6=service.getProduct(pname);
				System.out.println("ID:"+p6.getId());
				System.out.println("NAME:"+p6.getName());
				System.out.println("Quantity:"+p6.getQuantity());
				System.out.println("Price:"+p6.getPrice());
				
				
			}
			catch(ProductException e)
			{
				System.out.println("Product NOt Found:"+e.getMessage());
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
			break;
		case 7:
			for(Product product:service.getProductInRange(500,2000 ) )
					{
				System.out.println(product);
					}
			break;
		case 9:
			System.exit(0);
			break;
			
			
			
		}
		
		
	}

	public static void main(String arg[])
	{
		
		Menu application=new Menu();
		while(true)
		{try
		{
			application.menu();
		}
	catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		}
	}
}
