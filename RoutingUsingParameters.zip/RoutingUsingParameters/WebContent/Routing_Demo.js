var app=angular.module("mainApp",["ngRoute"])
	.config(function($routeProvider){
	$routeProvider.
	when("/fruits",{templateUrl:"Fruits.html",controller:"fruitcntrl" }).
	when("/veg",{templateUrl:"Veggies.html",controller:"vegetablecntrl"}).
	when("/details/:foodId",{templateUrl:"Details.html",controller:"descpcntrl"}).
	otherwise({
		redirectTo:'/fruits'
	})
	
});



/******** Description Controller**********/

app.controller("descpcntrl",function($scope,$routeParams,fruitService,$route){
	
	 var pid=$routeParams.foodId;
	$scope.foodItem=fruitService.getFood(pid);
	console.log($scope.foodItem);
	console.log($route.current.params.sciName);
	
$scope.reload=function(){
	$route.reload();
	
}
	
	
});

/*********Fruit Controller***********/
app.controller("fruitcntrl",function($scope,fruitService){
	
	$scope.fruits=fruitService.getFruit();
	console.log($scope.fruits)
});


/*************** vegetable Controller***************/
	app.controller("vegetablecntrl",function($scope,fruitService){
	$scope.veggies=fruitService.getVegetables();
	console.log($scope.veggies);
});
