import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {Component} from '@angular/core';
@Component ({
    selector : 'my-app',
    template: ` 
               <style>
                   .custom {
                       color:red;
                       text-transform:uppercase
                   }
               </style>
               <div>
                    <h1> This is the heading </h1>
                    <h3 class="custom"> Template Inline Style </h3>
                    <h3 class="sty"> Styling using styleUrl </h3>
               </div>            
                
             `,
    styles: ['h1 {color:blue}'],  
    styleUrls:['./style.component.css']       


 })
export class StyleComponent {

}
@NgModule({
    declarations: [StyleComponent],
    imports: [ BrowserModule ],
    bootstrap: [StyleComponent]
 })
export class AppModule {}