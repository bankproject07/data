import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {Component} from '@angular/core';
import {FormsModule} from '@angular/forms';
@Component ({
    selector : 'my-app',
    template:`  
             <div>
             <h1> Two way binding demo </h1>
             <input type="text" [(ngModel)]='name' />
             <br>
             <span [innerText]='greetmessage'> </span>
             <button (click)="greet()"> sayHi </button>
        `  
})
export class TwowayBindingComponent {
      name:string="Anil";
      greetmessage:string="";
      greet():void {
          this.greetmessage= "Hello " + this.name;
      }
}
@NgModule({
    declarations: [TwowayBindingComponent],
    imports: [ BrowserModule,FormsModule ],
    bootstrap: [TwowayBindingComponent]
 })
export class AppModule {}