
package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entity.Product;
import com.cg.exception.ProductException;
@Repository("dao")
public class ProductDaoImpl  implements IPoductDao
{
	@PersistenceContext
private  EntityManager manager; 
	Product p1=null;
	
	
	public ProductDaoImpl() 
	{
		
	}

	@Override
	public int addProduct(Product product) throws ProductException {
		int productId=0;
		try{
			manager.persist(product);
			productId=product.getId();
		}
		catch(Exception e)
		{
			throw new ProductException(e.getMessage());
		}
		return productId;
	}

	@Override
	public Product getProduct(int pid) throws ProductException 
	{
		System.out.println("Inside dao");
	try
	{
		p1=manager.find(Product.class,pid);
		System.out.println(p1);
		
	}
	catch(Exception e)
	{
		throw new ProductException(e.getMessage());
	}
	if(p1 == null)
		throw new ProductException("No Product Found with id " + pid);

		return p1;
	}

	@Override
	public List<Product> getAllProduct() throws ProductException {
		List <Product>plist=null;
		try
		{
			 String select="select p from Product p";
			 TypedQuery<Product>query=manager.createQuery(select,Product.class);
			 plist=query.getResultList();
		}
		catch(Exception e)
		{
			throw new ProductException(e.getMessage());
		}
		return plist;
	}

	@Override
	public Product getProduct(String name) throws ProductException {
	
		Product product=null;
		try
		{
			manager.getTransaction().begin();	
		
			String str="select product from Product product where product.name=:name";
			TypedQuery<Product>query=manager.createQuery(str,Product.class);	
			query.setParameter("name","java");
			product=query.getSingleResult();
		System.out.println(product);
		}

		
		catch(Exception e)
		{ 
		
		}
		if(product==null)
		{
			throw new ProductException("No Product to display:::");
		}
		
		return product;


	}

	@Override
	public void updateProduct(Product product) throws ProductException
	{
		try
		{			
			manager.merge(product);
			manager.flush();
						
		}
		catch(Exception e)
		{
			throw new ProductException(e.getMessage());
	}

}

	@Override
	public void removeProduct(int id) throws ProductException {
		Product p2=null;
		
		try
		{
			p2=manager.find(Product.class,id);
			manager.remove(p2);
		}
		catch(Exception e)
		{
			throw new ProductException(e.getMessage()); 
		}
		
	}

}
