package com.cg.dao;

import java.util.List;

import com.cg.entity.Product;
import com.cg.exception.ProductException;

public interface IPoductDao {

public int addProduct(Product product)throws ProductException;
public Product  getProduct(int pid)throws ProductException;
public List<Product>getAllProduct() throws ProductException;
public Product getProduct(String name)throws ProductException;
public void updateProduct(Product product)throws ProductException;
public void removeProduct(int id)throws ProductException;

}
