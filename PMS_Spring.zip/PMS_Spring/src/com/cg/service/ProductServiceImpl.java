package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IPoductDao;
import com.cg.dao.ProductDaoImpl;
import com.cg.entity.Product;
import com.cg.exception.ProductException;

@Transactional
@Service("productService")
public class ProductServiceImpl implements IProductService {
	@Autowired
	private IPoductDao dao;

	public ProductServiceImpl()
	{	  }
	

	public IPoductDao getDao() {
		return dao;
	}


	public void setDao(IPoductDao dao) {
		this.dao = dao;
	}


	@Override
	public int addProduct(Product product) throws ProductException {
		// TODO Auto-generated method stub
		return dao.addProduct(product);
	}

	@Override
	public Product getProduct(int pid) throws ProductException {
		System.out.println("Inside Service class");
		return dao.getProduct(pid);
	}

	@Override
	public List<Product> getAllProduct() throws ProductException {
		// TODO Auto-generated method stub
		return dao.getAllProduct();
	}

	@Override
	public Product getProduct(String name) throws ProductException {
		// TODO Auto-generated method stub
		return dao.getProduct(name);
	}

	@Override
	public void updateProduct(Product product) throws ProductException {
		dao.updateProduct(product);
		
	}

	@Override
	public void removeProduct(int id) throws ProductException {
		dao.removeProduct(id);
		
	}

}
