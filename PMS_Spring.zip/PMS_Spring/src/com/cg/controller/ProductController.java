package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entity.Product;
import com.cg.service.IProductService;
@Controller
public class ProductController
{
@Autowired
	IProductService productService;

public ProductController() 
{   }

public ProductController(IProductService productService) {
	super();
	this.productService = productService;
}

public IProductService getProductService() {
	return productService;
}

public void setProductService(IProductService productService) 
{
	this.productService = productService;
}
@RequestMapping("home")
public String getHomePage()
{
	return "HomePage";
}

@RequestMapping("addProduct")
public String getAddProductPage(Model model)
{
	List<String>list=new ArrayList<>();
	list.add("Books");
	list.add("Food");
	list.add("Electronics");
	list.add("shopping");
	
	model.addAttribute("product",new Product());
	model.addAttribute("CategoryList",list);
	
	
	return "AddProduct";
}

	@RequestMapping(value="ProcessAddProductForm")
	public ModelAndView ProcessAddProductForm(@ModelAttribute("product") @Valid Product product ,BindingResult result, Model model)
	{
		if(result.hasErrors()==true)
		{
			List<String>list=new ArrayList<>();
			list.add("Books");
			list.add("Food");
			list.add("Electronics");
			list.add("shopping");
			
			model.addAttribute("product",new Product());
			model.addAttribute("CategoryList",list);
			
			
			return new ModelAndView("AddProduct");
		}
		int productid=-1;
		try
		{
			productid=productService.addProduct(product);
			model.addAttribute("message","Product Added Succesfully: "+productid);
			return new ModelAndView("SuccessPage");
		}
		catch(Exception e)
		{
		 model.addAttribute("error","Error Occurs:");
		 return new ModelAndView("Failure");
		}
		
}
	
	/****************************************************************/
	
	
		@RequestMapping("getProduct")
		public String getProductPage()
		{
			return "GetProductPage";
		}
		
		@RequestMapping(value="processGetProductForm")
		public ModelAndView GetProductForm(@RequestParam("pid") int id ,Model model)
		{ 
		
		try
		{
			Product p1=null;
			p1=productService.getProduct(id);
		
			return new ModelAndView("GetProductPage","Product",p1);
		}
		catch(Exception e)
		{
			 model.addAttribute("error","Error Occurs:");
			 return new ModelAndView("Failure");
		}
		
}
		/************** *********************/
		
		@RequestMapping("viewAllProduct")
		public String getListpage(Model model)
		{try{
			List<Product>list=new ArrayList<>();
			list=productService.getAllProduct();
			if(list==null)
				
			{
				model.addAttribute("error","Error Occurs:");
				 return "Failure";
			}
			model.addAttribute("productList",list);
			return "ViewListPage";
		}
		catch(Exception e)
		{
			model.addAttribute("error","Error Occurs:");
			 return "Failure";
		}
			
		}
/*************************************************************/
		/*@RequestMapping("getProductByName")
		public String getProductByName()
		{
			return "GetProductByNamePage";
		}


		@RequestMapping("processproductform")
		public ModelAndView GetProductByName(@RequestParam("name") String pname ,Model model)
		{ 
		
		try
		{
			Product p1=null;
			p1=productService.getProduct(pname);
			System.out.println(p1);
		
			return new ModelAndView("GetProductByNamePage","Product",p1);
		}
		catch(Exception e)
		{
			 model.addAttribute("error","Error Occurs:");
			 return new ModelAndView("Failure");
		}
		
}*/
		/*****************************/
		
@RequestMapping("getupdatepage")
public String getUpdate(@RequestParam("pid")int uid,Model model)
{
	System.out.println(uid);
	List<String>list=new ArrayList<>();
	list.add("Books");
	list.add("Food");
	list.add("Electronics");
	list.add("shopping");
	Product product=null;
	try{
		product=productService.getProduct(uid);
	}
	catch(Exception e)
	{
		 model.addAttribute("error","Error Occurs:");
		 return "Failure";
	}
	
	model.addAttribute("product",product);
	model.addAttribute("CategoryList",list);
	
	return "Updatepage";
	
}

@RequestMapping(value="ProcessUpdateForm")
public String processUpdateForm(@ModelAttribute("product") Product product,Model model)
{
	try{
	productService.updateProduct(product);
	model.addAttribute("message","Product Updated Succesfully: "+product.getId());
	}
	catch(Exception e)
	{
		 model.addAttribute("error","Error Occurs:");
		 return "Failure";
	}
	return "SuccessPage";
}

}