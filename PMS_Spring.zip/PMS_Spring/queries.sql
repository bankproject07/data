select * from Product;
delete from product where id=4970;
create sequence product_hseq start with 5000 increment by 10;


