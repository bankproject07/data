package com.cg.dao;

import java.util.List;

import com.cg.entity.Product;
import com.cg.exception.ProductException;

public class ProductDaoImpl  implements IPoductDao
{

	@Override
	public int addProduct(Product product) throws ProductException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Product getProduct(int pid) throws ProductException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getAllProduct() throws ProductException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product getProduct(String name) throws ProductException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateProduct(Product product) throws ProductException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeProduct(int id) throws ProductException {
		// TODO Auto-generated method stub
		
	}

}
