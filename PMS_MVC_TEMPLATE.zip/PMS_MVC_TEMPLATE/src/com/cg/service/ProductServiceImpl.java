package com.cg.service;

import java.util.List;

import com.cg.dao.IPoductDao;
import com.cg.dao.ProductDaoImpl;
import com.cg.entity.Product;
import com.cg.exception.ProductException;

public class ProductServiceImpl implements IProductService {
	private IPoductDao dao;

	public ProductServiceImpl() 
	{
		super();
		
	dao=new ProductDaoImpl();
	}

	@Override
	public int addProduct(Product product) throws ProductException {
		// TODO Auto-generated method stub
		return dao.addProduct(product);
	}

	@Override
	public Product getProduct(int pid) throws ProductException {
		// TODO Auto-generated method stub
		return dao.getProduct(pid);
	}

	@Override
	public List<Product> getAllProduct() throws ProductException {
		// TODO Auto-generated method stub
		return dao.getAllProduct();
	}

	@Override
	public Product getProduct(String name) throws ProductException {
		// TODO Auto-generated method stub
		return dao.getProduct(name);
	}

	@Override
	public void updateProduct(Product product) throws ProductException {
		dao.updateProduct(product);
		
	}

	@Override
	public void removeProduct(int id) throws ProductException {
		dao.removeProduct(id);
		
	}

}
