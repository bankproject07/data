
create table Product_details(
id number primary key,
name varchar(20),
price number
);

create sequence pro_nseq start with 1000 ;