package com.cg.view;

import java.util.Scanner;

import com.cg.bean.Product;
import com.cg.exception.ProductException;
import com.cg.sercive.IProductService;
import com.cg.sercive.ProductServiceImpl;

public class MainApp
{

	IProductService service=new ProductServiceImpl();
	public void menu(){
		System.out.println("Product Management system");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Your Choice");
		System.out.println("1:= Add Product");
		System.out.println("2:= Get Product by id");
		System.out.println("3:= update Product");
		System.out.println("4:= Remove Product");
		System.out.println("5:= View All  Product");	
		System.out.println("6:= Get Product  by Name");
		
		System.out.println("9:= Exit");
		int c=sc.nextInt();
		switch (c) {
		case 1:
			
			System.out.println("Enter product name");
			String p1=sc.next();
			System.out.println("Enter category name");
			String c1=sc.next();
			System.out.println("Enter quantity");
			int q=sc.nextInt();
			System.out.println("Enter price");
			int pr=sc.nextInt();
		try{
			Product pro=new Product(p1,q,c1,pr);
			int pid=service.addProduct(pro);
			System.out.println("Product Inserted Sucessfully id:"+pro.getId());
		}
		catch(Exception e)
		{ throw new ProductException(e.getMessage());
		}
			break;

		default:
			break;
		}
	}
	
	public static void main(String arg[])
	{
		
		MainApp app=new MainApp();
		while(true)
	{
			app.menu();
	}
		
	}
}
