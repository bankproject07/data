package com.cg.test;

import java.util.Scanner;



import com.cg.bean.Product;
import com.cg.sercive.IProductService;
import com.cg.sercive.ProductServiceImpl;

public class Test {
	
		public static void main(String arg[])
	{
			
			System.out.println("/*********************************/");
		IProductService service=new ProductServiceImpl();
	/*	
	Product pro=new Product();
	pro.setName("iphone");
	pro.setCategory("Phone");
	pro.setQuantity(1);
	pro.setPrice(60000);
		
service.addProduct(pro);*/
		
/*	System.out.println("List Of Products:");
	  service.getAllProducts();*/
		
	//  service.getProduct(0);
	  
	  
	 service.getProductByName("Galaxy-Y");
		
		//service.removeProduct(1006);
	
	//Product p=new Product(1007,"iphone",15,"Phone",60000);
		
	//service.updateProduct(p);
	
	 
	}

}
