package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.bean.Product;
import com.cg.exception.ProductException;
import com.cg.util.DBUtil;

public class ProductDaoImpl implements IProductDao {
 private EntityManager em;


public ProductDaoImpl() {
	super();
	em=DBUtil.getEntityManager();
}

@Override
public int addProduct(Product product) throws ProductException
{int pid=-1;
	try{
		System.out.println("Inside add method:");
		em.getTransaction().begin();
		em.persist(product);
		System.out.println("Product details "+product);
		 pid=product.getId();
		 System.out.println("Product Id:"+pid);
		em.getTransaction().commit();
	}
	catch(Exception e)
	{
		if(em.getTransaction().isActive()){
		em.getTransaction().rollback();
		}
		
		throw new ProductException(e.getMessage());
		
		
	}
	return pid;

}

@Override
public Product getProduct(int id) throws ProductException {
	
	Product p=null;

	try
	{
		em.getTransaction().begin();
		p=em.find(Product.class,id);
		System.out.println(p);
		em.getTransaction().commit();
	
	}
	catch(Exception e)
	{
		//em.getTransaction().rollback();
		throw new ProductException("no data added");
	
	}
	return p;
}

@Override
public Product getProductByName(String name) throws ProductException {
	Product pro=null;
	
	try{
		
		em.getTransaction().begin();
		String qry="select p from Product p where p.name=name";
		TypedQuery<Product>query=em.createQuery(qry,Product.class);
		pro=query.getSingleResult();
		System.out.println(pro);
	}
	
	catch(Exception e)
	{
		em.getTransaction().rollback();
		throw new ProductException("no data added");
	
	}
	return pro;
}

@Override
public List<Product> getAllProducts() throws ProductException {
	List<Product>products=null;
	try
	{
		
		em.getTransaction().begin();
		String qry="select p from Product p ";
			TypedQuery<Product>tquery=em.createQuery(qry,Product.class);
		products=tquery.getResultList();
		System.out.println(products);
		
	}
	catch(Exception e)
	{
		
		throw new ProductException("no data");

	}

	return products;
}

@Override
public void updateProduct(Product product) throws ProductException {
	// TODO Auto-generated method stub
	try
	{
		em.getTransaction().begin();
		em.merge(product);
		em.flush();
		em.getTransaction().commit();
	}
	catch(Exception e)
	{
		
		throw new ProductException("no data added");

	}

	
}

@Override
public void removeProduct(int id) throws ProductException {
try
{
	em.getTransaction().begin();
	em.remove(id);
	em.getTransaction().commit();
	
}
catch(Exception e)
{

	throw new ProductException("no data added");

}

	
}
	
}
