package com.cg.sercive;

import java.util.List;

import com.cg.bean.Product;
import com.cg.dao.IProductDao;
import com.cg.dao.ProductDaoImpl;
import com.cg.exception.ProductException;

public class ProductServiceImpl  implements IProductService{
	private IProductDao dao;
	
	

	public ProductServiceImpl() {
	super();
		dao=new ProductDaoImpl();
	}

	@Override
	public int addProduct(Product product) throws ProductException {
		// TODO Auto-generated method stub
		return dao.addProduct(product);
	}

	@Override
	public Product getProduct(int id) throws ProductException {
		// TODO Auto-generated method stub
		return dao.getProduct(id);
	}

	@Override
	public Product getProductByName(String name) throws ProductException {
		// TODO Auto-generated method stub
		return dao.getProductByName(name);
	}

	@Override
	public List<Product> getAllProducts() throws ProductException {
		System.out.println("Inside Service Class");
		return dao.getAllProducts();
	}

	@Override
	public void updateProduct(Product product) throws ProductException {
		dao.updateProduct(product);
		
	}

	@Override
	public void removeProduct(int id) throws ProductException {
		dao.removeProduct(id);
		
	}

}
