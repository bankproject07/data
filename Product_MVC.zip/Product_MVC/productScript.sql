create table Product(
 id number(5)primary key,
 name varchar(10),
 category varchar(10),
 quantity number(4),
 price number
);


create sequence pro_seq start with 1000 ;

insert into Product values(pro_seq.nextVal,'MiNote4','Phone',2,15000);

select pro_seq.nextVal from dual;
select * from Product;

select * from PRODUCT where id=1002;

select * from Product where name='MiNote4';
delete from Product where id=1005;
update Product set quantity=5 where id=1007;