package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.bean.Product;
import com.cg.exception.ProductException;
import com.cg.util.DBUtil;

public class ProductDaoImpl implements IProductDao {
 Statement st;
 PreparedStatement ps;
 ResultSet rs;
 //1: method
 
	@Override
	public int addProduct(Product product) throws ProductException {
	
		int data=-1;
		try(Connection con=DBUtil.getConnection())
		{
			st=con.createStatement();
			rs=st.executeQuery("select pro_seq.nextVal from dual");
			if(rs.next()==false)
			{
				throw new ProductException("Sequence for id  not generatred");
			}
			PreparedStatement ps=con.prepareStatement("insert into Product values(?,?,?,?,?)");
			ps.setInt(1,rs.getInt(1));
			ps.setString(2,product.getName());
			ps.setString(3,product.getCategory());
			ps.setInt(4, product.getQuantity());
			ps.setInt(5,product.getPrice());
			data=ps.executeUpdate();
		
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
		catch(Exception e)
		{
			throw new ProductException("Data not generated for id:"+data);
		}
		return data;
	}
//********** 2**********//
	@Override
	public Product getProduct(int id) throws ProductException {
		Product np=new Product();
		try(Connection con=DBUtil.getConnection())
		{
			System.out.println("Inside Dao getProduct");
	
			ps=con.prepareStatement("select * from Product where id=?");
			ps.setInt(1, id);
			rs=ps.executeQuery();
			rs.next();
			np.setId(rs.getInt(1));
			np.setName(rs.getString(2));
			np.setCategory(rs.getString(3));
			np.setQuantity(rs.getInt(4));
			np.setPrice(rs.getInt(5));
		System.out.println(np);
		}
		catch(Exception e)
		{
			throw new ProductException("No data found:");
		}
		
		return np;
	}

//********** 2**********//

	
	@Override
	public Product getProductByName(String name) throws ProductException {
		Product np=new Product();
		try(Connection con=DBUtil.getConnection())
		{
			System.out.println("inside Get by name");
			ps=con.prepareStatement("select * from Product where name=?");
					ps.setString(1,name);
			rs=ps.executeQuery();
			rs.next();
			np.setName(rs.getString("name"));
			np.setId(rs.getInt("id"));
			np.setCategory(rs.getString("category"));
			np.setQuantity(rs.getInt("quantity"));
			np.setPrice(rs.getInt("price"));
			System.out.println(np);
		}
		catch(Exception e)
		{
			throw new ProductException("No data found:");
		}
		
	
		return np;
	}
//********** 2**********//

	@Override
	public List<Product> getAllProducts() throws ProductException {
		List<Product> plist=new ArrayList<Product>();
		try(Connection con=DBUtil.getConnection())
		{
			System.out.println("Inside dao List method");
			st=con.createStatement();
			rs=st.executeQuery("select * from Product");
			while(rs.next())
			{
				Product np=new Product();
				np.setId(rs.getInt(1));
				np.setName(rs.getString(2));
				np.setCategory(rs.getString(3));
				np.setQuantity(rs.getInt(4));
				np.setPrice(rs.getInt(5));
				plist.add(np);
				System.out.println(plist);
			}
		}
		catch(Exception e)
		{
			throw new ProductException("Prodct List is empty");
		}
		return plist;
	}

	
	//********** 2**********//
	
	@Override
	public void updateProduct(Product product) throws ProductException {
		try(Connection con=DBUtil.getConnection())
		{

			ps=con.prepareStatement("update Product set quantity=? where id=?");
			
			ps.setInt(1,product.getQuantity());
			ps.setInt(2,product.getId());
			
			/*ps.setString(3,product.getName());
			ps.setString(4,product.getCategory());
			ps.setInt(5,product.getPrice());
		
		*/	ps.execute();
			
		System.out.println("data updated");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			throw new ProductException("no data found:");
		}
		System.out.println("Updated Information ");
		
	}

	
	//********** 2**********//

	
	@Override
	public void removeProduct(int id) throws ProductException {
		// TODO Auto-generated method stub
		
		try(Connection con=DBUtil.getConnection())
		{
			ps=con.prepareStatement("delete from Product where id=?");
			ps.setInt(1, id);
			rs=ps.executeQuery();
			System.out.println("Data removed:"+id);
		}
		catch(Exception e)
		{
			throw new ProductException("Data removed");
		}
		System.out.println("Removing Data:");
	}

}
