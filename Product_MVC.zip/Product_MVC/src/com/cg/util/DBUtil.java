package com.cg.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import oracle.jdbc.pool.OracleDataSource;

public class DBUtil {

	public static Connection getConnection() throws SQLException

	{
		/*InitialContext ic;
		DataSource ds;
		*/
		Connection con=null;
		try{
			if(con==null)
			{
		

	OracleDataSource ods = new OracleDataSource();

	ods.setUser("system");

	ods.setPassword("tiger");

	ods.setDriverType("thin");

	ods.setNetworkProtocol("tcp");

	ods.setURL("jdbc:oracle:thin:@localhost:1521:XE");

	return ods.getConnection();
	
	
	 /*ic = new InitialContext();
		ds = (DataSource)
				ic.lookup("java:/jdbc/OracleDS");
		con=ds.getConnection();
	*/
	
	
	//return con;

}
			

	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
	}

}
