package com.cg.test;

import java.util.Scanner;

import com.cg.bean.Product;
import com.cg.sercive.IProductService;
import com.cg.sercive.ProductServiceImpl;

public class Test {
	
	public void showMenu()
	{Scanner sc=new Scanner(System.in);
		System.out.println("Enter Your Choice:");
		int c=sc.nextInt();
		switch (c) {
		case 1:addData();
			
			break;

		default:
			break;
		}
	}
	public void addData() {
		
		
	}
	public static void main(String arg[])
	{
		IProductService service=new ProductServiceImpl();
		
	Product pro=new Product();
	pro.setName("iphone");
	pro.setCategory("Phone");
	pro.setQuantity(1);
	pro.setPrice(60000);
		
	//	service.addProduct(pro);*/
		
	//System.out.println("List Of Products:");
	  //service.getAllProducts();
		
	  //service.getProduct(1002);
	  
	  
	//  service.getProductByName("MiNote4");
		
		//service.removeProduct(1006);
	
	Product p=new Product(1007,"iphone",15,"Phone",60000);
		
		service.updateProduct(p);
	
	 
	}

}
